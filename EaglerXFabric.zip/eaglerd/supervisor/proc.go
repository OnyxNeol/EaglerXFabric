package supervisor

import (
	"os"
	"strconv"
	"strings"
)

// sampleProc reads CPU jiffies (utime+stime) and RSS bytes of a process from
// /proc. On non-Linux systems it reports ok=false and sampling is skipped.
// jiffies is returned in units of USER_HZ ticks (100/s on Linux).
func sampleProc(pid int) (jiffies, rssBytes int64, ok bool) {
	if _, err := os.Stat("/proc"); err != nil {
		return 0, 0, false
	}
	data, err := os.ReadFile("/proc/" + strconv.Itoa(pid) + "/stat")
	if err != nil {
		return 0, 0, false
	}
	// The comm field can contain spaces and parens; skip past the last ')'.
	i := strings.LastIndexByte(string(data), ')')
	if i < 0 {
		return 0, 0, false
	}
	fields := strings.Fields(string(data[i+2:]))
	if len(fields) < 13 { // state .. stime
		return 0, 0, false
	}
	utime, err1 := strconv.ParseInt(fields[11], 10, 64) // utime
	stime, err2 := strconv.ParseInt(fields[12], 10, 64) // stime
	if err1 != nil || err2 != nil {
		return 0, 0, false
	}

	var rss int64
	if st, err := os.ReadFile("/proc/" + strconv.Itoa(pid) + "/status"); err == nil {
		for _, line := range strings.Split(string(st), "\n") {
			if strings.HasPrefix(line, "VmRSS:") {
				f := strings.Fields(line)
				if len(f) >= 2 {
					if kb, err := strconv.ParseInt(f[1], 10, 64); err == nil {
						rss = kb * 1024
					}
				}
				break
			}
		}
	}
	return utime + stime, rss, true
}
