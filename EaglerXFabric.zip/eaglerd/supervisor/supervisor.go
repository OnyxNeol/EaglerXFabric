// Package supervisor manages the lifecycle of one JVM process: the Fabric
// game server ("backend") or the Velocity + EaglerXServer gateway
// ("gateway").
//
// The supervisor design is carried over from the system extracted from
// EaglerCMP (eaglercmp/manager/jvm.go) and extended for server deployments:
//
//   - exponential backoff restarts with a fast-fail threshold (3 quick
//     crashes => error state, no infinite retry loop)
//   - loopback port readiness probing before clients are routed
//   - live CPU / RSS resource sampling from /proc (Linux)
//   - graceful stop via the server console ("stop\n" on stdin) before
//     escalating to SIGINT/SIGKILL, so mod changes and restarts never
//     corrupt the world
package supervisor

import (
	"context"
	"fmt"
	"io"
	"log"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"eaglerd/config"
)

// State is a backend state reported to the API.
type State string

const (
	StateDisabled State = "disabled" // backend.enabled=false
	StateStopped  State = "stopped"  // stopped by the user, waiting for a start
	StateStarting State = "starting" // JVM booting, port not yet accepting
	StateReady    State = "ready"    // port accepting connections
	StateStopping State = "stopping" // graceful stop in progress
	StateError    State = "error"    // gave up; needs a manual restart
)

const (
	fastFailWindow = 20 * time.Second // exits sooner than this count as failed starts
	maxFastFails   = 3                // then stop retrying until restarted by the user
	minBackoff     = time.Second
	maxBackoff     = 30 * time.Second
	sigIntWait     = 5 * time.Second
	sampleEvery    = 2 * time.Second
	defaultGrace   = 20 * time.Second
)

// Status is a point-in-time snapshot of a backend, safe to serialize.
type Status struct {
	State      string  `json:"state"`
	Error      string  `json:"error,omitempty"`
	PID        int     `json:"pid,omitempty"`
	UptimeSec  int64   `json:"uptimeSec"`
	Restarts   int     `json:"restarts"`
	CPUPercent float64 `json:"cpuPercent"`
	RSSMB      int64   `json:"rssMB"`
	ListenAddr string  `json:"listenAddr"`
	Dir        string  `json:"dir"`
	Jar        string  `json:"jar"`
	LogFile    string  `json:"logFile"`
}

// Backend supervises the local JVM server (Fabric/Paper with Eaglercraft
// support and mods in <Dir>/mods) and restarts it with backoff if it dies.
// Problems are recorded in Status so the API can report them; a server that
// cannot start is not retried in a loop.
type Backend struct {
	Name    string // "backend" or "gateway": default dir, log file and log prefix
	DefPort int    // listen port when Cfg.Port is unset
	Cfg     config.Backend
	LogDir  string
	Log     *log.Logger

	mu       sync.Mutex
	state    State
	errMsg   string
	pid      int
	started  time.Time
	restarts int
	cpu      float64
	rssKB    int64

	kick    chan struct{} // restart / start request
	stopReq chan struct{} // graceful stop request
}

// NewBackend creates a supervisor; it only runs once Run is called.
func NewBackend(name string, defPort int, cfg config.Backend, logDir string, log *log.Logger) *Backend {
	st := StateDisabled
	if cfg.Enabled {
		st = StateStarting
	}
	return &Backend{
		Name: name, DefPort: defPort, Cfg: cfg, LogDir: logDir, Log: log, state: st,
		kick: make(chan struct{}, 1), stopReq: make(chan struct{}, 1),
	}
}

// Dir is the server directory (world, mods/, jar).
func (b *Backend) Dir() string {
	if b.Cfg.Dir != "" {
		return b.Cfg.Dir
	}
	return filepath.Join(".", b.Name)
}

// ModsDir is where uploaded .jar mods are placed.
func (b *Backend) ModsDir() string { return filepath.Join(b.Dir(), "mods") }

// Addr is the loopback endpoint the process listens on.
func (b *Backend) Addr() string {
	return fmt.Sprintf("127.0.0.1:%d", b.Cfg.EffPort(b.DefPort))
}

// LogPath is the file backend console output is appended to.
func (b *Backend) LogPath() string { return filepath.Join(b.LogDir, b.Name+".log") }

// Status returns the current state and, for StateError, a human-readable cause.
func (b *Backend) Status() (state, msg string) {
	b.mu.Lock()
	defer b.mu.Unlock()
	return string(b.state), b.errMsg
}

// Snapshot returns the full status report including resource usage.
func (b *Backend) Snapshot() Status {
	b.mu.Lock()
	defer b.mu.Unlock()
	st := Status{
		State:      string(b.state),
		Error:      b.errMsg,
		PID:        b.pid,
		Restarts:   b.restarts,
		CPUPercent: b.cpu,
		RSSMB:      b.rssKB / 1024,
		ListenAddr: b.Addr(),
		Dir:        b.Dir(),
		Jar:        b.Cfg.Jar,
		LogFile:    b.LogPath(),
	}
	if b.pid != 0 {
		st.UptimeSec = int64(time.Since(b.started).Seconds())
	}
	return st
}

func (b *Backend) set(state State, msg string) {
	b.mu.Lock()
	b.state, b.errMsg = state, msg
	b.mu.Unlock()
	if state == StateError {
		b.Log.Printf("%s: %s", b.Name, msg)
	}
}

func (b *Backend) setProc(pid int) {
	b.mu.Lock()
	b.pid, b.started, b.cpu, b.rssKB = pid, time.Now(), 0, 0
	b.mu.Unlock()
}

func (b *Backend) clearProc() {
	b.mu.Lock()
	b.pid, b.cpu, b.rssKB = 0, 0, 0
	b.mu.Unlock()
}

func (b *Backend) setMetrics(cpu float64, rssKB int64) {
	b.mu.Lock()
	b.cpu, b.rssKB = cpu, rssKB
	b.mu.Unlock()
}

func (b *Backend) incrRestarts() {
	b.mu.Lock()
	b.restarts++
	b.mu.Unlock()
}

// Restart stops the running server (if any) and starts it again; it also
// recovers a backend that gave up after an error.
func (b *Backend) Restart() {
	select {
	case b.kick <- struct{}{}:
	default:
	}
}

// Stop gracefully stops the server and leaves it in StateStopped.
func (b *Backend) Stop() {
	select {
	case b.stopReq <- struct{}{}:
	default:
	}
}

// Start (re)starts the server; same as Restart.
func (b *Backend) Start() { b.Restart() }

func (b *Backend) java() string {
	if b.Cfg.Java != "" {
		return b.Cfg.Java
	}
	return "java"
}

// Preflight checks that the server can be started: a runnable Java and a jar.
func (b *Backend) Preflight() error {
	jar := filepath.Join(b.Dir(), b.Cfg.Jar)
	if st, err := os.Stat(jar); err != nil || st.IsDir() {
		return fmt.Errorf("%s jar %q not found: put it in %s (run scripts/setup.sh)", b.Name, b.Cfg.Jar, b.Dir())
	}
	bin, err := exec.LookPath(b.java())
	if err != nil {
		return fmt.Errorf("Java not found (%q): install a JDK 21+ or set backend.java", b.java())
	}
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	if out, err := exec.CommandContext(ctx, bin, "-version").CombinedOutput(); err != nil {
		return fmt.Errorf("Java at %s is not runnable: %v: %s", bin, err, strings.TrimSpace(string(out)))
	}
	return nil
}

// command builds the JVM command line: java <jvmArgs> -jar <jar> <args...>.
func (b *Backend) command() *exec.Cmd {
	args := append([]string{}, b.Cfg.JVMArgs...)
	args = append(args, "-jar", b.Cfg.Jar)
	if b.Cfg.Args != nil {
		args = append(args, b.Cfg.Args...)
	} else {
		args = append(args, "nogui")
	}
	cmd := exec.Command(b.java(), args...)
	cmd.Dir = b.Dir()
	return cmd
}

// gracefulStop asks a running server to exit cleanly: first "stop" on the
// console (Fabric/Velocity both honor it), then SIGINT, then SIGKILL. done
// carries the result of cmd.Wait() and is always drained.
func (b *Backend) gracefulStop(cmd *exec.Cmd, stdin io.WriteCloser, done <-chan error) {
	timeout := defaultGrace
	if b.Cfg.GracefulStopSec > 0 {
		timeout = time.Duration(b.Cfg.GracefulStopSec) * time.Second
	}
	if stdin != nil {
		io.WriteString(stdin, "stop\n")
		stdin.Close()
	}
	select {
	case <-done:
		return
	case <-time.After(timeout):
	}
	if cmd.Process != nil {
		cmd.Process.Signal(os.Interrupt)
	}
	select {
	case <-done:
		return
	case <-time.After(sigIntWait):
	}
	if cmd.Process != nil {
		cmd.Process.Kill()
	}
	<-done
}

// waitStopped blocks while the server is stopped until a start is requested;
// false means ctx ended.
func (b *Backend) waitStopped(ctx context.Context) bool {
	b.set(StateStopped, "")
	for ctx.Err() == nil {
		select {
		case <-ctx.Done():
			return false
		case <-b.kick:
			return true
		case <-b.stopReq:
			// already stopped; ignore redundant stop
		}
	}
	return false
}

// waitEvent blocks during error/dead states for a restart (kick), a stop
// request, or ctx end. true means "try starting again".
func (b *Backend) waitEvent(ctx context.Context) bool {
	for ctx.Err() == nil {
		select {
		case <-ctx.Done():
			return false
		case <-b.kick:
			return true
		case <-b.stopReq:
			return b.waitStopped(ctx)
		}
	}
	return false
}

// Run starts the JVM and keeps it running until ctx is cancelled. It blocks.
// Derived from EaglerCMP's Backend.Run, extended with stdin (console),
// resource sampling and manual stop support.
func (b *Backend) Run(ctx context.Context) {
	if !b.Cfg.Enabled {
		b.set(StateDisabled, "")
		return
	}
	for _, d := range []string{b.Dir(), b.ModsDir(), b.LogDir} {
		if err := os.MkdirAll(d, 0o755); err != nil {
			b.set(StateError, err.Error())
			return
		}
	}
	logf, err := os.OpenFile(b.LogPath(), os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o644)
	if err != nil {
		b.set(StateError, err.Error())
		return
	}
	defer logf.Close()

	backoff, fails := minBackoff, 0
	for ctx.Err() == nil {
		if err := b.Preflight(); err != nil {
			b.set(StateError, err.Error())
			if !b.waitEvent(ctx) {
				return
			}
			continue
		}
		b.set(StateStarting, "")
		cmd := b.command()
		cmd.Stdout, cmd.Stderr = logf, logf
		stdin, _ := cmd.StdinPipe()
		if err := cmd.Start(); err != nil {
			b.set(StateError, "start: "+err.Error())
			if !b.waitEvent(ctx) {
				return
			}
			continue
		}
		start := time.Now()
		b.setProc(cmd.Process.Pid)
		runCtx, cancel := context.WithCancel(ctx)
		exitCh := make(chan error, 1)
		go func() { exitCh <- cmd.Wait() }()
		go b.waitReady(runCtx)
		go b.sampleLoop(runCtx, cmd.Process.Pid)
		b.Log.Printf("%s: starting %s (logs: %s)", b.Name, cmd.String(), b.LogPath())

		var runErr error
		select {
		case <-ctx.Done():
			b.set(StateStopping, "")
			b.gracefulStop(cmd, stdin, exitCh)
			cancel()
			b.clearProc()
			b.set(StateStopped, "")
			return
		case <-b.kick: // user-requested restart
			b.set(StateStopping, "")
			b.gracefulStop(cmd, stdin, exitCh)
			cancel()
			b.clearProc()
			continue
		case <-b.stopReq: // user-requested stop
			b.set(StateStopping, "")
			b.gracefulStop(cmd, stdin, exitCh)
			cancel()
			b.clearProc()
			if !b.waitStopped(ctx) {
				return
			}
			continue
		case runErr = <-exitCh:
			cancel()
			b.clearProc()
		}

		if ctx.Err() != nil {
			return
		}
		b.Log.Printf("%s: exited: %v", b.Name, runErr)

		// A stop/restart may have raced the exit; honor it.
		select {
		case <-b.kick:
			continue
		case <-b.stopReq:
			if !b.waitStopped(ctx) {
				return
			}
			continue
		default:
		}

		if time.Since(start) < fastFailWindow {
			fails++
		} else {
			fails, backoff = 0, minBackoff
		}
		if fails >= maxFastFails {
			b.set(StateError, fmt.Sprintf("%s crashed %d times right after starting; last output: %s",
				b.Name, fails, Tail(b.LogPath(), 400)))
			if !b.waitEvent(ctx) {
				return
			}
			fails, backoff = 0, minBackoff
			continue
		}
		b.incrRestarts()
		b.set(StateStarting, "")
		select {
		case <-ctx.Done():
			return
		case <-b.kick:
			continue
		case <-b.stopReq:
			if !b.waitStopped(ctx) {
				return
			}
			continue
		case <-time.After(backoff):
		}
		if backoff < maxBackoff {
			backoff *= 2
		}
	}
}

// waitReady polls the loopback port and flips the state to ready.
func (b *Backend) waitReady(ctx context.Context) {
	for i := 0; i < 300 && ctx.Err() == nil; i++ {
		if c, err := net.DialTimeout("tcp", b.Addr(), time.Second); err == nil {
			c.Close()
			if ctx.Err() == nil {
				b.set(StateReady, "")
				b.Log.Printf("%s: ready on %s", b.Name, b.Addr())
			}
			return
		}
		time.Sleep(time.Second)
	}
	if ctx.Err() == nil {
		b.set(StateError, b.Name+" is running but nothing listens on "+b.Addr()+": check its config and "+b.LogPath())
	}
}

// sampleLoop tracks CPU and memory usage of the supervised JVM process.
func (b *Backend) sampleLoop(ctx context.Context, pid int) {
	t := time.NewTicker(sampleEvery)
	defer t.Stop()
	var prevJiffies float64
	prev := time.Now()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
		}
		jif, rss, ok := sampleProc(pid)
		if !ok {
			continue
		}
		now := time.Now()
		d := now.Sub(prev).Seconds()
		total := float64(jif)
		if prevJiffies > 0 && d > 0 {
			cpu := (total - prevJiffies) / 100.0 / d * 100.0 // USER_HZ=100
			b.setMetrics(cpu, rss)
		}
		prevJiffies, prev = total, now
	}
}

// Tail returns the last n bytes of a file, trimmed, for error messages.
func Tail(path string, n int) string {
	data, err := os.ReadFile(path)
	if err != nil {
		return err.Error()
	}
	if len(data) > n {
		data = data[len(data)-n:]
	}
	return strings.TrimSpace(string(data))
}
