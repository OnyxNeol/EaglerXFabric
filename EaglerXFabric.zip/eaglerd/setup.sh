#!/usr/bin/env bash
# setup.sh — provision the full Eaglercraft -> Fabric stack for eaglerd.
#
# Adapted from the system extracted from EaglerCMP (scripts/setup-local-stack.sh),
# reworked for server deployments (configurable versions, loopback-only binds).
#
# Creates next to eaglerd.json:
#   backend/  Fabric game server (127.0.0.1:25566), your .jar mods go in backend/mods
#   gateway/  Velocity + EaglerXServer (+ ViaVersion/ViaBackwards): the Eaglercraft
#             WebSocket listener (same port as Velocity, 127.0.0.1:25577) that forwards
#             standard Minecraft packets to Fabric. The daemon bridges clients to it.
#
# Env:
#   MC_VERSION        Minecraft version for Fabric (default 1.21.1, needs Java 21)
#   VELOCITY_BUILD    Velocity build number (default: latest from PaperMC API)
#   EAGLERD_CONFIG    config path to write (default: eaglerd.json)
#   EAGLERXSERVER_URL direct URL to the EaglerXServer plugin jar (skip Modrinth lookup)
#   VIARELEASE...     VIARELEASE_URL / VIABACKWARDS_URL / FABRIC_API_URL to pin any
#                     dependency to a direct jar URL instead of the Modrinth API.
#
# Running this accepts the Minecraft EULA (https://aka.ms/MinecraftEULA).
set -eu
cd "$(dirname "$0")"

mc="${MC_VERSION:-1.21.1}"
cfg="${EAGLERD_CONFIG:-eaglerd.json}"
be="backend"; gw="gateway"

fetch() { # fetch <url> <dest>
  echo "  <- $1"
  curl -fsSL --retry 3 -o "$2" "$1"
}
modrinth() { # modrinth <slug-or-url> <dest-dir> — latest release jar for Velocity
  local slug="$1" dir="$2" url
  url=$(curl -fsS "https://api.modrinth.com/v2/project/$slug/version?loaders=%5B%22velocity%22%5D" \
    | jq -r '[.[] | select(.version_type=="release")][0].files[0].url // empty')
  [ -n "$url" ] || { echo "warning: no velocity build of $slug on Modrinth (set ${slug^^}_URL to pin a direct jar)" >&2; return 0; }
  fetch "$url" "$dir/$(basename "$url")"
}

echo "== provisioning Fabric $mc backend =="
mkdir -p "$be/mods"
if [ ! -f "$be/fabric-server-launch.jar" ] || [ "$(cat "$be/.mc-version" 2>/dev/null)" != "$mc" ]; then
  rm -rf "$be/.fabric" "$be/libraries" "$be/versions"
  loader=$(curl -fsS https://meta.fabricmc.net/v2/versions/loader | sed -n 's/.*"version": "\([^"]*\)".*/\1/p' | head -1)
  installer=$(curl -fsS https://meta.fabricmc.net/v2/versions/installer | sed -n 's/.*"version": "\([^"]*\)".*/\1/p' | head -1)
  fetch "https://meta.fabricmc.net/v2/versions/loader/$mc/$loader/$installer/server/jar" "$be/fabric-server-launch.jar"
  echo "$mc" > "$be/.mc-version"
fi
# Fabric API (most server-side mods depend on it)
if ! ls "$be"/mods/fabric-api-*.jar >/dev/null 2>&1; then
  if [ -n "${FABRIC_API_URL:-}" ]; then
    fetch "$FABRIC_API_URL" "$be/mods/$(basename "$FABRIC_API_URL")"
  else
    url=$(curl -fsS "https://api.modrinth.com/v2/project/fabric-api/version?loaders=%5B%22fabric%22%5D&game_versions=%5B%22$mc%22%5D" \
      | jq -r '[.[] | select(.version_type=="release")][0].files[0].url // empty')
    [ -n "$url" ] && fetch "$url" "$be/mods/$(basename "$(printf %s "$url" | sed 's/%2B/+/g')")" \
      || echo "warning: no Fabric API release for $mc on Modrinth; set FABRIC_API_URL" >&2
  fi
fi
echo "eula=true" > "$be/eula.txt"
[ -f "$be/server.properties" ] || printf 'online-mode=false\nserver-ip=127.0.0.1\nserver-port=25566\nenforce-secure-profile=false\n' > "$be/server.properties"

echo "== provisioning Velocity + EaglerXServer gateway =="
mkdir -p "$gw/plugins"
if [ ! -f "$gw/velocity.jar" ]; then
  # Fill v3: pick the newest Velocity whose Java minimum fits the current JVM
  entry=$(curl -fsS https://fill.papermc.io/v3/projects/velocity/versions | jq -r --argjson j "$(java -version 2>&1 | head -1 | grep -oE '[0-9]+' | head -1)" '
    .versions
    | map(select((.version.java.version.minimum // 0) <= $j and (.builds | length) > 0))
    | (map(select((.version.id | endswith("-SNAPSHOT")) | not) | select(.version.support.status == "SUPPORTED"))[0]
       // map(select(.version.id | endswith("-SNAPSHOT") | not))[0] // .[0])')
  build=$(printf %s "$entry" | jq -r '.version.id')
  bld=$(printf %s "$entry" | jq -r '.builds[-1]')
  fetch "$(curl -fsS "https://fill.papermc.io/v3/projects/velocity/versions/$build/builds/$bld" | jq -r '.downloads["server:default"].url // .downloads["server:java"].url')" "$gw/velocity.jar"
fi
for p in "eaglercraftxserver" "viaversion" "viabackwards"; do
  dir="$gw/plugins"
  if [ "$p" = "eaglerxserver" ] && [ -n "${EAGLERXSERVER_URL:-}" ]; then
    fetch "$EAGLERXSERVER_URL" "$dir/$(basename "$EAGLERXSERVER_URL")"; continue
  fi
  modrinth "$p" "$dir"
done
# Fabric server only listens on 127.0.0.1, so forwarding stays "none".
[ -f "$gw/velocity.toml" ] || cat > "$gw/velocity.toml" <<TOML
config-version = "2.7"
bind = "127.0.0.1:25577"
motd = "eaglerd gateway"

[servers]
fabric = "127.0.0.1:25566"
try = ["fabric"]

[forced-hosts]
TOML

if [ ! -f "$cfg" ]; then
  echo "== writing $cfg =="
  cat > "$cfg" <<JSON
{
  "listenPort": 25565,
  "bridgePath": "/",
  "apiPrefix": "/api",
  "authToken": "",
  "maxModMB": 256,
  "logDir": "logs",
  "backend": {"enabled": true, "name": "Modded Fabric Server", "jar": "fabric-server-launch.jar", "jvmArgs": ["-Xmx2G"], "port": 25566},
  "gateway": {"enabled": true, "jar": "velocity.jar", "jvmArgs": ["-Xmx512M"], "args": [], "port": 25577}
}
JSON
fi

echo
echo "stack ready. start the daemon with:"
echo "  ./eaglerd -config $cfg"
echo "clients connect to:  ws(s)://<your-host>:25565/   (bridged -> gateway 25577 -> fabric 25566)"
