#!/usr/bin/env python3
"""Scale test: hundreds of Eaglercraft clients joining in a burst.

Boots the real plugin JVM (same harness as test_plugin.py, fake gateway),
then fires N concurrent WebSocket clients that each complete the full
exchange: TCP connect -> HTTP upgrade -> greeting frame -> masked
echo. Simulates a join burst. Asserts every client succeeds and the
server stays healthy afterwards.

Run: python3 test_scale.py [N]
"""
import base64
import concurrent.futures
import http.server
import json
import os
import signal
import socket
import struct
import subprocess
import sys
import time
import urllib.request

EAGLERD = "/app/conversations/6ad32a084ce18c326740c5a2/eaglerd"
JAR = f"{EAGLERD}/dist/eaglerd-plugin-1.2.0.jar"
GAME = "/tmp/plugin-scale"
PORT, GW_PORT, MIRROR = 18080, 18082, 18085
N = int(sys.argv[1]) if len(sys.argv) > 1 else 500


class Mirror(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-Length", "516")
        self.end_headers()
        self.wfile.write(b"PK\x03\x04" + b"M" * 512)

    def log_message(self, *a):
        pass


def wait_ready(token, timeout=90):
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            req = urllib.request.Request(f"http://127.0.0.1:{PORT}/api/status",
                                         headers={"X-Api-Token": token})
            with urllib.request.urlopen(req, timeout=3) as r:
                d = json.load(r)
                if d.get("gateway", {}).get("state") == "ready":
                    return d
        except Exception:
            pass
        time.sleep(0.5)
    raise SystemExit("plugin/gateway never became ready")


def one_client(i):
    """Full Eaglercraft-style exchange. Returns (ok, seconds, error)."""
    t0 = time.time()
    s = None
    phase = "connect"
    try:
        s = socket.create_connection(("127.0.0.1", PORT), timeout=15)
        phase = "upgrade"
        s.settimeout(15)
        key = base64.b64encode(os.urandom(16)).decode()
        s.sendall((f"GET / HTTP/1.1\r\nHost: c{i}\r\nUpgrade: websocket\r\n"
                   f"Connection: Upgrade\r\nSec-WebSocket-Key: {key}\r\n"
                   f"Sec-WebSocket-Version: 13\r\n\r\n").encode())
        resp = b""
        while b"\r\n\r\n" not in resp:
            chunk = s.recv(2048)
            if not chunk:
                return False, time.time() - t0, f"{phase}: closed"
            resp += chunk
        if b"101" not in resp.split(b"\r\n")[0]:
            return False, time.time() - t0, "no 101"
        buf = resp.split(b"\r\n\r\n", 1)[1]  # frames may ride in the same packet

        def rf():
            nonlocal buf
            while len(buf) < 2:
                buf += s.recv(2048)
            ln = buf[1] & 0x7F
            while len(buf) < 2 + ln:
                buf += s.recv(2048)
            p, buf = buf[2:2 + ln], buf[2 + ln:]
            return p

        phase = "greeting"
        greeting = rf()
        phase = "echo"
        payload = f"PLAYER-{i}".encode()
        m = os.urandom(4)
        masked = bytes(b ^ m[j % 4] for j, b in enumerate(payload))
        s.sendall(bytes([0x82, 0x80 | len(payload)]) + m + masked)
        echo = rf()
        if echo != b"GATEWAY-ECHO:" + payload:
            return False, time.time() - t0, f"bad echo {echo[:20]!r}"
        # hold the connection briefly like a joining player would
        time.sleep(1.0)
        return True, time.time() - t0, None
    except Exception as e:
        return False, time.time() - t0, f"{phase}: {str(e)[:60]}"
    finally:
        if s:
            try:
                s.close()
            except OSError:
                pass


def main():
    subprocess.run(["pkill", "-9", "-f", "plugin-scale"], capture_output=True)
    subprocess.run(["pkill", "-9", "-f", "jvmgw"], capture_output=True)
    time.sleep(0.6)
    subprocess.run(["rm", "-rf", GAME])
    os.makedirs(f"{GAME}/mods", exist_ok=True)
    os.chdir(GAME)
    open(f"{GAME}/server.properties", "w").write(
        "server-port=%d\nonline-mode=true\n" % PORT)

    srv = http.server.HTTPServer(("127.0.0.1", MIRROR), Mirror)
    import threading
    threading.Thread(target=srv.serve_forever, daemon=True).start()

    env = dict(os.environ,
               EAGLERD_LISTEN_PORT=str(PORT),
               EAGLERD_BACKEND_PORT="18081",
               EAGLERD_GATEWAY_PORT=str(GW_PORT),
               EAGLERD_AUTO_SETUP="1",
               EAGLERD_VELOCITY_URL=f"http://127.0.0.1:{MIRROR}/velocity.jar",
               EAGLERD_EAGLERX_URL=f"http://127.0.0.1:{MIRROR}/eaglerxserver-1.2.jar",
               EAGLERD_VIAVERSION_URL=f"http://127.0.0.1:{MIRROR}/viaversion-5.jar",
               EAGLERD_VIABACKWARDS_URL=f"http://127.0.0.1:{MIRROR}/viabackwards-5.jar",
               EAGLERD_VIAREWIND_URL=f"http://127.0.0.1:{MIRROR}/viarewind-4.jar",
               EAGLERD_JAVA="/tmp/fakebin/java")
    proc = subprocess.Popen([
        "/opt/jdk/bin/java",
        "-cp", f"{JAR}:{EAGLERD}/vendor-jars/fabric-loader.jar:"
               f"{EAGLERD}/vendor-jars/slf4j-api.jar:{EAGLERD}/vendor-jars/slf4j-simple.jar",
        "dev.eaglerd.plugin.EaglerdPlugin",
    ], env=env, stdout=open("plugin.out", "w"), stderr=subprocess.STDOUT)

    try:
        token = None
        deadline = time.time() + 30
        while time.time() < deadline:
            try:
                token = json.load(open(f"{GAME}/eaglerd-plugin.json"))["authToken"]
                break
            except (OSError, json.JSONDecodeError, KeyError):
                time.sleep(0.3)
        if not token:
            raise SystemExit("plugin never wrote its config")
        st = wait_ready(token)
        print(f"stack ready (gateway pid {st['gateway']['pid']})")

        def run_wave(count, label, per_sec=None):
            print(f"firing {label}...")
            t0 = time.time()
            with concurrent.futures.ThreadPoolExecutor(max_workers=count) as ex:
                if per_sec:
                    futures = []
                    batch = max(1, per_sec // 5)
                    i = 0
                    while i < count:
                        end = min(i + batch, count)
                        futures.extend(ex.submit(one_client, j) for j in range(i, end))
                        i = end
                        time.sleep(0.2)
                    results = [f.result() for f in futures]
                else:
                    results = list(ex.map(one_client, range(count)))
            dt = time.time() - t0
            ok = [r for r in results if r[0]]
            lat = sorted(r[1] for r in ok)
            p50 = lat[len(lat) // 2]
            p95 = lat[int(len(lat) * 0.95)]
            print(f"{label}: {len(ok)}/{count} succeeded in {dt:.1f}s "
                  f"(p50 {p50:.2f}s, p95 {p95:.2f}s, max {lat[-1]:.2f}s)")
            for f in [r for r in results if not r[0]][:5]:
                print("  FAIL:", f[2])
            return len(ok), count

        burst_ok, burst_n = run_wave(N, f"strict burst of {N} (all simultaneous)")
        wave_ok, wave_n = run_wave(max(N, 500), f"join wave of {max(N, 500)} players at ~50/s", per_sec=50)
        results = [(True, 0, None)]  # placeholder for compat

        # server still healthy after the burst?
        with urllib.request.urlopen(
                urllib.request.Request(f"http://127.0.0.1:{PORT}/healthz",
                                       ), timeout=5) as r:
            healthy = r.status == 200
        print("post-burst healthz:", "OK" if healthy else "DOWN")

        assert burst_ok == burst_n, f"burst: only {burst_ok}/{burst_n} completed"
        assert wave_ok == wave_n, f"wave: only {wave_ok}/{wave_n} completed"
        assert healthy
        print(f"SCALE-TEST-PASSED (burst of {burst_n} simultaneous + wave of {wave_n} joins, all smooth)")
    finally:
        proc.send_signal(signal.SIGTERM)
        try:
            proc.wait(timeout=25)
            print("plugin shut down gracefully")
        except subprocess.TimeoutExpired:
            proc.kill()
        srv.shutdown()
        subprocess.run(["pkill", "-9", "-f", "plugin-scale"], capture_output=True)
        subprocess.run(["pkill", "-9", "-f", "jvmgw"], capture_output=True)


if __name__ == "__main__":
    raise SystemExit(main())
