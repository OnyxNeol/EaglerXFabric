package dev.eaglerd.plugin;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Mod ingestion engine for the Fabric server this plugin runs in: uploads
 * land in <gameDir>/mods (this server's own mods folder) after a ZIP
 * signature check, written atomically so the server never sees a partial
 * jar. Ported from the extracted EaglerCMP mod manager (manager/mods.go).
 */
public final class ModsStore {
    private static final Pattern NAME = Pattern.compile("^[A-Za-z0-9][A-Za-z0-9._+() -]{0,120}\\.jar$");

    private final Path dir;
    private final long maxBytes;

    public ModsStore(Path dir, long maxBytes) {
        this.dir = dir;
        this.maxBytes = maxBytes;
    }

    /** Lists installed .jar mods (name + size), sorted by name. */
    public List<Map<String, Object>> list() {
        List<Map<String, Object>> out = new ArrayList<>();
        try (var s = Files.list(dir)) {
            s.filter(p -> p.getFileName().toString().endsWith(".jar") && Files.isRegularFile(p))
                .sorted(Comparator.comparing(p -> p.getFileName().toString()))
                .forEach(p -> {
                    Map<String, Object> m = new LinkedHashMap<>();
                    m.put("name", p.getFileName().toString());
                    try { m.put("size", Files.size(p)); } catch (IOException e) { m.put("size", -1L); }
                    out.add(m);
                });
        } catch (IOException e) {
            // directory missing: empty list
        }
        return out;
    }

    /**
     * Validates and stores an uploaded jar. Returns null on success or a
     * human-readable error message.
     */
    public String save(String name, byte[] data) throws IOException {
        if (name == null || !NAME.matcher(name).matches()) {
            return "invalid file name: use letters, digits and . _ + - ( ) and end with .jar";
        }
        if (data.length > maxBytes) {
            return "mod exceeds the maximum upload size";
        }
        if (data.length < 4 || data[0] != 'P' || data[1] != 'K' || data[2] != 3 || data[3] != 4) {
            return "file is not a valid .jar (missing zip signature or empty)";
        }
        Files.createDirectories(dir);
        Path tmp = Files.createTempFile(dir, ".upload-", null);
        Files.write(tmp, data);
        try {
            Files.move(tmp, dir.resolve(name), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            Files.deleteIfExists(tmp);
            return "store failed: " + e;
        }
        return null;
    }

    /** Deletes a mod; returns null on success or an error message. */
    public String remove(String name) {
        if (name == null || !NAME.matcher(name).matches()) {
            return "invalid file name";
        }
        try {
            Files.deleteIfExists(dir.resolve(name));
            return null;
        } catch (IOException e) {
            return "delete failed: " + e;
        }
    }
}
