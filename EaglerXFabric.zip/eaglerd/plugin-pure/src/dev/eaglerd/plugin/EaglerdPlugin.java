package dev.eaglerd.plugin;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.SecureRandom;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.fabricmc.api.ModInitializer;

/**
 * eaglerd-plugin: the entire eaglerd system as one independent Fabric
 * server-side plugin.
 *
 * Everything runs inside the Fabric JVM — no external daemon, no embedded
 * native binary, no sidecar:
 *
 *   - Eaglercraft WebSocket bridge (public :25565, byte-level tunnel to the
 *     gateway's Eaglercraft listener, port of EaglerCMP's manager/bridge.go)
 *   - Gateway JVM supervisor: spawns Velocity + EaglerXServer, probes the
 *     loopback port, restarts with backoff, 3-fast-fail error state,
 *     /proc CPU/RAM sampling, graceful console "stop" shutdown
 *   - Mod ingestion API: upload .jar mods into this server's mods/ folder
 *     with ZIP signature verification, plus list/delete/restart/stop/status
 *
 * First boot is hands-off: server.properties is patched (with backup), the
 * gateway/ directory is auto-provisioned (Velocity, EaglerXServer,
 * ViaVersion, ViaBackwards, ViaRewind, velocity.toml) and a ready-to-use config with a
 * generated management token is written.
 *
 * The Fabric server that loaded this mod IS the backend.
 *
 * Standalone smoke test (no Fabric needed):
 *   java -cp eaglerd-plugin.jar:fabric-loader.jar:slf4j-api.jar dev.eaglerd.plugin.EaglerdPlugin
 */
public final class EaglerdPlugin implements ModInitializer {
    private static final Logger LOG = LoggerFactory.getLogger("eaglerd-plugin");
    private static GatewaySupervisor gateway;
    private static EaglerdHttpServer http;

    @Override
    public void onInitialize() {
        start();
    }

    public static void main(String[] args) throws Exception {
        start();
        Thread.currentThread().join(); // keep the JVM alive until SIGINT/SIGTERM
    }

    static void start() {
        try {
            Path gameDir = Paths.get(System.getProperty("user.dir"));
            Files.createDirectories(gameDir.resolve("mods"));
            Path cfgFile = gameDir.resolve("eaglerd-plugin.json");
            if (!Files.exists(cfgFile)) {
                writeDefaultConfig(cfgFile);
                LOG.info("created default config {} (edit it, then restart to apply changes)", cfgFile.getFileName());
            }
            Config cfg = Config.load(cfgFile);

            // friendly server.properties fix (backup: server.properties.eaglerd.bak)
            if (cfg.autoFixServerProperties) {
                String changes = ServerProperties.fix(cfg, LOG);
                if (changes != null) {
                    LOG.info("server.properties fixed for Eaglercraft: {}", changes);
                }
            }

            // first-boot gateway provisioning (setup.sh equivalent)
            if (cfg.gatewayEnabled && cfg.autoSetup) {
                String err = Setup.ensureGateway(cfg, LOG);
                if (err == null) {
                    LOG.info("gateway ready: gateway/ is provisioned");
                } else {
                    LOG.error("gateway auto-provisioning failed: {} — gateway/ is incomplete;"
                            + " run the server online once, or install Velocity + EaglerXServer"
                            + " into gateway/ manually", err);
                    GatewaySupervisor.setSetupHint(err);
                }
            }

            ModsStore mods = new ModsStore(cfg.modsDir, (long) cfg.maxModMB << 20);
            gateway = new GatewaySupervisor(cfg, LOG);
            http = new EaglerdHttpServer(cfg, gateway, mods, LOG);
            http.start();
            Thread t = new Thread(gateway, "eaglerd-gateway");
            t.setDaemon(true);
            t.start();
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                http.stop();
                gateway.shutdown(); // graceful gateway stop via console "stop"
                try {
                    t.join(30_000); // wait for the graceful stop to finish
                } catch (InterruptedException ignored) {
                }
            }, "eaglerd-shutdown"));

            if (cfg.authToken.isEmpty()) {
                LOG.warn("authToken is empty: anyone who can reach port {} can manage this server."
                        + " Set \"authToken\" in eaglerd-plugin.json", cfg.listenPort);
            }
            banner(cfg);
        } catch (Exception e) {
            LOG.error("eaglerd-plugin failed to start", e);
        }
    }

    private static void banner(Config cfg) {
        String host = "your-server";
        String proto = cfg.listenPort == 443 ? "wss" : "ws";
        LOG.info("");
        LOG.info("==============================================================");
        LOG.info("  eaglerd is up!  Eaglercraft players connect to:");
        LOG.info("      {}://{}:{}/", proto, host, cfg.listenPort);
        LOG.info("");
        LOG.info("  gateway (supervised) : {}", cfg.gatewayEnabled ? cfg.gatewayAddr() : "disabled");
        LOG.info("  Fabric backend       : {}", cfg.backendAddr());
        LOG.info("  management           : http://{}:{}/api/status  (token required)", host, cfg.listenPort);
        if (!cfg.authToken.isEmpty()) {
            LOG.info("  your API token       : {}  (also in eaglerd-plugin.json)", cfg.authToken);
        }
        LOG.info("  mod uploads          : POST http://{}:{}/api/mods?name=<mod>.jar", host, cfg.listenPort);
        LOG.info("==============================================================");
        LOG.info("");
    }

    /** Writes a documented, ready-to-use default config with a random token. */
    private static void writeDefaultConfig(Path file) throws Exception {
        String token = newToken();
        String cfg = """
                {
                  "listenPort": 25565,
                  "bridgePath": "/",
                  "apiPrefix": "/api",
                  "authToken": "%s",
                  "maxModMB": 256,

                  "setup": {
                    "autoSetup": true,
                    "autoFixServerProperties": true,
                    "backendPort": 25566,
                    "velocityVersion": "",
                    "velocityUrl": "",
                    "eaglerxUrl": "",
                    "viaVersionUrl": "",
                    "viaBackwardsUrl": "",
                    "viaRewindUrl": ""
                  },

                  "gateway": {
                    "enabled": true,
                    "java": "java",
                    "dir": "gateway",
                    "jar": "velocity.jar",
                    "jvmArgs": ["-Xmx512M"],
                    "args": [],
                    "port": 25577,
                    "gracefulStopSec": 20
                  }
                }
                """.formatted(token);
        Files.writeString(file, cfg);
        LOG.info("generated a management API token: {} (keep it secret; it is in eaglerd-plugin.json)", token);
    }

    private static String newToken() {
        byte[] b = new byte[12];
        new SecureRandom().nextBytes(b);
        StringBuilder s = new StringBuilder(24);
        for (byte x : b) {
            s.append(String.format("%02x", x));
        }
        return s.toString();
    }
}
