package dev.eaglerd.plugin;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.slf4j.Logger;

/**
 * Keeps server.properties safe for an Eaglercraft setup — the three classic
 * first-boot mistakes fixed automatically, with a one-time backup:
 *
 *   - server-port collides with the Eaglercraft listener (25565) -> moved to
 *     the backend port
 *   - online-mode=true -> false ( Eaglercraft players have no Mojang session)
 *   - enforce-secure-profile=true with offline mode -> false
 *   - server-ip unset (backend exposed to the internet) -> 127.0.0.1
 *
 * The Fabric server reads server.properties after mods initialize, so the
 * fix applies to the very first boot. Never touches values a user pinned
 * deliberately (an explicit server-ip other than empty/0.0.0.0 stays).
 */
public final class ServerProperties {
    private ServerProperties() {}

    /**
     * Patches server.properties if needed. Returns a human-readable summary
     * of the changes, or null if nothing needed fixing (or the file does not
     * exist — e.g. standalone smoke test).
     */
    public static String fix(Config cfg, Logger log) {
        Path props = cfg.gameDir.resolve("server.properties");
        if (!Files.exists(props)) {
            return null;
        }
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(props)) {
            p.load(in);
        } catch (IOException e) {
            return null;
        }
        List<String> changes = new ArrayList<>();

        String port = p.getProperty("server-port", "25565");
        int backendPort = cfg.backendPort;
        if (port.equals(String.valueOf(cfg.listenPort))) {
            p.setProperty("server-port", String.valueOf(backendPort));
            changes.add("server-port: " + port + " -> " + backendPort
                    + " (25565 is the Eaglercraft port)");
        } else {
            backendPort = Integer.parseInt(port);
        }

        if (!"false".equals(p.getProperty("online-mode", "true"))) {
            p.setProperty("online-mode", "false");
            changes.add("online-mode: true -> false (Eaglercraft players cannot authenticate)");
        }
        if (!"false".equals(p.getProperty("enforce-secure-profile", "false"))) {
            p.setProperty("enforce-secure-profile", "false");
            changes.add("enforce-secure-profile: true -> false (required with online-mode=false)");
        }
        String ip = p.getProperty("server-ip", "");
        if (ip.isEmpty() || ip.equals("0.0.0.0") || ip.equals("::")) {
            p.setProperty("server-ip", "127.0.0.1");
            changes.add("server-ip: unset -> 127.0.0.1 (only the gateway may reach the backend)");
        }
        if (changes.isEmpty()) {
            return null;
        }

        Path backup = cfg.gameDir.resolve("server.properties.eaglerd.bak");
        try {
            if (!Files.exists(backup)) {
                Files.copy(props, backup, StandardCopyOption.REPLACE_EXISTING);
            }
            try (OutputStream out = Files.newOutputStream(props)) {
                p.store(out, "patched by eaglerd-plugin (backup: server.properties.eaglerd.bak)");
            }
        } catch (IOException e) {
            log.warn("could not patch server.properties: {} — set server-port={}, online-mode=false, server-ip=127.0.0.1 manually",
                    e, backendPort);
            return null;
        }
        return String.join("; ", changes);
    }
}
