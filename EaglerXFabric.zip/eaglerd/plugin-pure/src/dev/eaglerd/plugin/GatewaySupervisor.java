package dev.eaglerd.plugin;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

import org.slf4j.Logger;

/**
 * Supervises the Velocity + EaglerXServer gateway JVM: automated spawning,
 * port readiness probing, exponential backoff restarts with a fast-fail
 * threshold, /proc resource sampling and graceful console ("stop") shutdown.
 *
 * This is the pure-Java port of the supervisor extracted from EaglerCMP
 * (eaglercmp/manager/jvm.go, Backend.Run), so the plugin embeds the same
 * proven lifecycle semantics as the standalone Go daemon.
 */
public final class GatewaySupervisor implements Runnable {
    public static final String DISABLED = "disabled", STOPPED = "stopped", STARTING = "starting",
            READY = "ready", STOPPING = "stopping", ERROR = "error";

    private static final long FAST_FAIL_WINDOW_MS = 20_000;
    private static final long MIN_BACKOFF_MS = 1_000, MAX_BACKOFF_MS = 30_000;
    private static final long SIGINT_WAIT_MS = 5_000, SAMPLE_MS = 2_000;

    private final Config cfg;
    private final Logger log;
    private final LinkedBlockingDeque<Object> signals = new LinkedBlockingDeque<>();
    private final AtomicLong generation = new AtomicLong();

    private static volatile String setupHint = "";

    /** Records why auto-provisioning failed (shown in preflight errors). */
    public static void setSetupHint(String hint) { setupHint = hint; }

    private volatile boolean running = true;
    private volatile String state = STARTING, errMsg = "";
    private volatile long startedAt, pid, restarts, rssKb;
    private volatile double cpu;

    public GatewaySupervisor(Config cfg, Logger log) {
        this.cfg = cfg;
        this.log = log;
        if (!cfg.gatewayEnabled) state = DISABLED;
    }

    /** Requests a restart (also recovers from the error state). */
    public void kick() { signals.offerLast("kick"); }

    /** Requests a graceful stop; the gateway stays stopped until kick(). */
    public void requestStop() { signals.offerLast("stop"); }

    /** Stops supervision and gracefully shuts the gateway down. */
    public void shutdown() { running = false; kick(); }

    public Map<String, Object> status() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("state", state);
        if (!errMsg.isEmpty()) m.put("error", errMsg);
        if (pid > 0) {
            m.put("pid", pid);
            m.put("uptimeSec", (System.currentTimeMillis() - startedAt) / 1000);
        }
        m.put("restarts", restarts);
        m.put("cpuPercent", cpu);
        m.put("rssMB", rssKb / 1024);
        m.put("listenAddr", cfg.gatewayAddr());
        m.put("dir", cfg.gatewayDir.toString());
        m.put("jar", cfg.gatewayJar);
        m.put("logFile", cfg.logDir.resolve("gateway.log").toString());
        return m;
    }

    public boolean isReady() { return READY.equals(state); }

    private void setState(String s, String err) {
        state = s;
        errMsg = err == null ? "" : err;
        if (ERROR.equals(s)) log.error("gateway: {}", errMsg);
    }

    @Override
    public void run() {
        if (!cfg.gatewayEnabled) {
            setState(DISABLED, null);
            return;
        }
        try {
            Files.createDirectories(cfg.gatewayDir);
            Files.createDirectories(cfg.logDir);
        } catch (IOException e) {
            setState(ERROR, e.toString());
            return;
        }
        long backoff = MIN_BACKOFF_MS;
        int fails = 0;
        while (running) {
            String pre = preflight();
            if (pre != null) {
                setState(ERROR, pre);
                if (!waitEvent()) return;
                continue;
            }
            setState(STARTING, null);
            Process p;
            try {
                p = startProcess();
            } catch (Exception e) {
                setState(ERROR, "start: " + e);
                if (!waitEvent()) return;
                continue;
            }
            long start = System.currentTimeMillis();
            log.info("gateway: starting (pid {}), logs: gateway.log", p.pid());

            CountDownLatch exitLatch = new CountDownLatch(1);
            watch(p, exitLatch);
            probe(p);
            sample(p);

            Object sig;
            try {
                sig = signals.takeFirst();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
            boolean crashed = "exit".equals(sig);
            log.info("supervisor signal: {} (running={})", sig, running);
            if (!running) {
                gracefulStop(p, exitLatch);
                setState(STOPPED, null);
                return;
            }
            if (crashed) {
                generation.incrementAndGet(); // stop probe/sampler of the dead process
                log.info("gateway: exited");
                if (System.currentTimeMillis() - start < FAST_FAIL_WINDOW_MS) {
                    fails++;
                } else {
                    fails = 0;
                    backoff = MIN_BACKOFF_MS;
                }
                if (fails >= 3) {
                    setState(ERROR, "gateway crashed " + fails
                            + " times right after starting; last output: " + tailLog(400));
                    if (!waitEvent()) return;
                    fails = 0;
                    backoff = MIN_BACKOFF_MS;
                    continue;
                }
                restarts++;
                setState(STARTING, null);
                if (!waitBackoff(backoff)) return;
                if (backoff < MAX_BACKOFF_MS) backoff *= 2;
                continue;
            }
            // kick or stop while running
            gracefulStop(p, exitLatch);
            if ("stop".equals(sig)) {
                setState(STOPPED, null);
                if (!waitStopped()) return;
            }
            // kick: restart immediately
        }
    }

    /**
     * The java binary for the gateway JVM. If "java" is not on the PATH
     * (common in minimal containers where the server itself was started
     * by absolute path), fall back to the JVM running the Fabric server.
     */
    private String resolveJava() throws IOException {
        if (!cfg.java.equals("java") && !cfg.java.equals("javaw")) {
            return cfg.java;
        }
        try {
            new ProcessBuilder(cfg.java, "-version").redirectErrorStream(true).start().destroy();
            return cfg.java;
        } catch (IOException e) {
            String fb = fallbackJava();
            if (fb != null) {
                log.info("java not on PATH; using {}", fb);
                return fb;
            }
            throw e;
        }
    }

    private static String fallbackJava() {
        Path bin = Paths.get(System.getProperty("java.home"), "bin",
                System.getProperty("os.name", "").toLowerCase().contains("win") ? "java.exe" : "java");
        return Files.exists(bin) ? bin.toString() : null;
    }

    private Process startProcess() throws IOException {
        List<String> cmd = new ArrayList<>();
        cmd.add(resolveJava());
        cmd.addAll(cfg.jvmArgs);
        cmd.add("-jar");
        cmd.add(cfg.gatewayJar);
        if (cfg.args.isEmpty()) {
            cmd.add("nogui");
        } else {
            cmd.addAll(cfg.args);
        }
        ProcessBuilder pb = new ProcessBuilder(cmd);
        pb.directory(cfg.gatewayDir.toFile());
        pb.redirectErrorStream(true);
        File logf = cfg.logDir.resolve("gateway.log").toFile();
        pb.redirectOutput(ProcessBuilder.Redirect.appendTo(logf));
        Process p = pb.start();
        startedAt = System.currentTimeMillis();
        pid = p.pid();
        return p;
    }

    private void watch(Process p, CountDownLatch latch) {
        final Process fp = p;
        Thread t = new Thread(() -> {
            try {
                fp.waitFor();
            } catch (InterruptedException ignored) {
            }
            signals.offerLast("exit");
            latch.countDown();
        }, "eaglerd-gw-watch");
        t.setDaemon(true);
        t.start();
    }

    /** Port readiness probe: polls the gateway loopback port (300s max). */
    private void probe(Process p) {
        long gen = generation.incrementAndGet();
        Thread t = new Thread(() -> {
            for (int i = 0; i < 300; i++) {
                if (gen != generation.get() || !p.isAlive()) return;
                try (Socket s = new Socket()) {
                    s.connect(new InetSocketAddress("127.0.0.1", cfg.gatewayPort), 1000);
                    if (gen == generation.get()) {
                        setState(READY, null);
                        log.info("gateway: ready on {}", cfg.gatewayAddr());
                    }
                    return;
                } catch (IOException ignored) {
                }
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    return;
                }
            }
            if (gen == generation.get() && p.isAlive()) {
                setState(ERROR, "gateway is running but nothing listens on "
                        + cfg.gatewayAddr() + ": check its config and logs/gateway.log");
            }
        }, "eaglerd-gw-probe");
        t.setDaemon(true);
        t.start();
    }

    /** CPU/RSS sampling of the gateway JVM from /proc. */
    private void sample(Process p) {
        long gen = generation.get();
        final double[] prevJif = {0};
        final long[] prevMs = {System.currentTimeMillis()};
        Thread t = new Thread(() -> {
            while (gen == generation.get() && p.isAlive()) {
                try {
                    Thread.sleep(SAMPLE_MS);
                } catch (InterruptedException e) {
                    return;
                }
                String stat = readFile("/proc/" + p.pid() + "/stat");
                if (stat == null) continue;
                int close = stat.lastIndexOf(')');
                if (close < 0) continue;
                String[] f = stat.substring(close + 2).trim().split("\\s+");
                if (f.length < 13) continue;
                double jif;
                try {
                    jif = Double.parseDouble(f[11]) + Double.parseDouble(f[12]);
                } catch (NumberFormatException e) {
                    continue;
                }
                long rss = 0;
                String st = readFile("/proc/" + p.pid() + "/status");
                if (st != null) {
                    for (String line : st.split("\n")) {
                        if (line.startsWith("VmRSS:")) {
                            String[] v = line.trim().split("\\s+");
                            if (v.length >= 2) {
                                try {
                                    rss = Long.parseLong(v[1]) * 1024;
                                } catch (NumberFormatException ignored) {
                                }
                            }
                            break;
                        }
                    }
                }
                long now = System.currentTimeMillis();
                double dsec = (now - prevMs[0]) / 1000.0;
                if (prevJif[0] > 0 && dsec > 0) {
                    cpu = (jif - prevJif[0]) / 100.0 / dsec * 100.0;
                    rssKb = rss;
                }
                prevJif[0] = jif;
                prevMs[0] = now;
            }
        }, "eaglerd-gw-sample");
        t.setDaemon(true);
        t.start();
    }

    /** Graceful stop: "stop" on the console, then destroy, then kill. */
    private void gracefulStop(Process p, CountDownLatch latch) {
        log.info("gracefulStop: writing stop to gateway console");
        setState(STOPPING, null);
        try {
            OutputStream stdin = p.getOutputStream();
            stdin.write("stop\n".getBytes(StandardCharsets.UTF_8));
            stdin.flush();
            stdin.close();
        } catch (IOException ignored) {
        }
        try {
            latch.await(cfg.gracefulStopSec, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
        }
        log.info("gracefulStop: stop written, exited={} after wait", !p.isAlive());
        if (p.isAlive()) {
            log.warn("gracefulStop: escalating to destroy()");
            p.destroy();
            try {
                latch.await(SIGINT_WAIT_MS, TimeUnit.MILLISECONDS);
            } catch (InterruptedException ignored) {
            }
        }
        if (p.isAlive()) {
            log.warn("gracefulStop: escalating to destroyForcibly()");
            p.destroyForcibly();
            try {
                latch.await(SIGINT_WAIT_MS, TimeUnit.MILLISECONDS);
            } catch (InterruptedException ignored) {
            }
        }
        log.info("gracefulStop: done, gateway alive={}", p.isAlive());
        generation.incrementAndGet();
        signals.remove("exit"); // drain the exit signal we already handled
        pid = 0;
        cpu = 0;
        rssKb = 0;
    }

    /** Waits during error/stopped states. True = try starting again. */
    private boolean waitEvent() {
        while (running) {
            Object sig;
            try {
                sig = signals.takeFirst();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return false;
            }
            if ("kick".equals(sig)) return true;
            if ("stop".equals(sig)) return waitStopped();
        }
        return false;
    }

    /** Blocks while stopped until a kick (start) arrives. */
    private boolean waitStopped() {
        setState(STOPPED, null);
        while (running) {
            Object sig;
            try {
                sig = signals.takeFirst();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return false;
            }
            if ("kick".equals(sig)) return true;
            // redundant stop while stopped: ignore
        }
        return false;
    }

    /** Waits the backoff, but a kick restarts now and a stop parks. */
    private boolean waitBackoff(long ms) {
        Object sig;
        try {
            sig = signals.pollFirst(ms, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        }
        if (sig == null) return true; // backoff elapsed: restart
        if ("kick".equals(sig)) return true;
        if ("stop".equals(sig)) return waitStopped();
        return running; // exit signal (process died again mid-wait): restart
    }

    /** Returns null when the gateway can start, else the failure reason. */
    private String preflight() {
        Path jar = cfg.gatewayDir.resolve(cfg.gatewayJar);
        if (!Files.isRegularFile(jar)) {
            if (!setupHint.isEmpty()) {
                return "gateway jar missing and auto-provisioning failed: " + setupHint
                        + " — run the server online once, or install Velocity + EaglerXServer"
                        + " into " + cfg.gatewayDir + " manually";
            }
            return "gateway jar \"" + cfg.gatewayJar + "\" not found in " + cfg.gatewayDir
                    + " (enable setup.autoSetup in eaglerd-plugin.json to download it automatically)";
        }
        try {
            Process p = new ProcessBuilder(resolveJava(), "-version").redirectErrorStream(true).start();
            if (!p.waitFor(10, TimeUnit.SECONDS)) {
                p.destroyForcibly();
                return "java -version timed out";
            }
            if (p.exitValue() != 0) {
                return "java at " + resolveJava() + " is not runnable (exit " + p.exitValue() + ")";
            }
        } catch (IOException e) {
            return "Java not found (" + cfg.java + " and " + fallbackJava() + "): install a JDK 21+ or set gateway.java";
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return "interrupted";
        }
        return null;
    }

    private String tailLog(int bytes) {
        try {
            byte[] data = Files.readAllBytes(cfg.logDir.resolve("gateway.log"));
            String s = new String(data, Math.max(0, data.length - bytes), Math.min(bytes, data.length), StandardCharsets.UTF_8);
            return s.trim();
        } catch (IOException e) {
            return e.toString();
        }
    }

    private static String readFile(String path) {
        try {
            return Files.readString(Path.of(path));
        } catch (IOException e) {
            return null;
        }
    }
}
