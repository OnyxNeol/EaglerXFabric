package dev.eaglerd.plugin;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** eaglerd-plugin configuration: eaglerd-plugin.json in the game directory
 * plus EAGLERD_* environment overrides. Mirrors the standalone daemon's
 * config, minus the backend supervisor (the Fabric server running this mod
 * IS the backend). */
public final class Config {
    public final Path gameDir = Paths.get(System.getProperty("user.dir"));

    public int listenPort = 25565;      // public WS + API port
    public String bridgePath = "/";     // Eaglercraft WebSocket endpoint
    public String apiPrefix = "/api";
    public String authToken = "";
    public int maxModMB = 256;
    public final Path logDir = gameDir.resolve("logs");
    public final Path modsDir = gameDir.resolve("mods"); // this Fabric server's mods

    // Gateway: the Velocity + EaglerXServer JVM this plugin supervises.
    public boolean gatewayEnabled = true;
    public String java = "java";
    public Path gatewayDir = gameDir.resolve("gateway");
    public String gatewayJar = "velocity.jar";
    public List<String> jvmArgs = new ArrayList<>(List.of("-Xmx512M"));
    public List<String> args = new ArrayList<>();
    public int gatewayPort = 25577;
    public int gracefulStopSec = 20;

    // First-boot friendliness (setup.sh equivalent, plus server.properties fix).
    public boolean autoSetup = true;          // provision gateway/ on first boot
    public boolean autoFixServerProperties = true;
    public int backendPort = 25566;           // this Fabric server's port
    public String velocityVersion = "";       // "" = latest
    public String velocityUrl = "";            // pin to skip the PaperMC lookup
    public String eaglerxUrl = "";             // pin to skip Modrinth
    public String viaVersionUrl = "";
    public String viaBackwardsUrl = "";
    public String viaRewindUrl = "";
    public String eaglerxrewindUrl =
            "https://github.com/lax1dude/eaglerxserver/releases/download/v1.1.1/EaglerXRewind.jar";

    public String backendAddr() { return "127.0.0.1:" + backendPort; }

    public String gatewayAddr() { return "127.0.0.1:" + gatewayPort; }

    @SuppressWarnings("unchecked")
    public static Config load(Path file) throws IOException {
        Config c = new Config();
        if (Files.exists(file)) {
            Object root = Json.parse(Files.readString(file));
            if (!(root instanceof Map)) {
                throw new IllegalArgumentException("config root must be an object");
            }
            Map<String, Object> m = (Map<String, Object>) root;
            c.listenPort = intOf(m.get("listenPort"), c.listenPort);
            c.bridgePath = strOf(m.get("bridgePath"), c.bridgePath);
            c.apiPrefix = strOf(m.get("apiPrefix"), c.apiPrefix);
            c.authToken = strOf(m.get("authToken"), c.authToken);
            c.maxModMB = intOf(m.get("maxModMB"), c.maxModMB);
            Object st = m.get("setup");
            if (st instanceof Map) {
                Map<String, Object> g = (Map<String, Object>) st;
                c.autoSetup = boolOf(g.get("autoSetup"), true);
                c.autoFixServerProperties = boolOf(g.get("autoFixServerProperties"), true);
                c.backendPort = intOf(g.get("backendPort"), c.backendPort);
                c.velocityVersion = strOf(g.get("velocityVersion"), c.velocityVersion);
                c.velocityUrl = strOf(g.get("velocityUrl"), c.velocityUrl);
                c.eaglerxUrl = strOf(g.get("eaglerxUrl"), c.eaglerxUrl);
                c.viaVersionUrl = strOf(g.get("viaVersionUrl"), c.viaVersionUrl);
                c.viaBackwardsUrl = strOf(g.get("viaBackwardsUrl"), c.viaBackwardsUrl);
                c.viaRewindUrl = strOf(g.get("viaRewindUrl"), c.viaRewindUrl);
                c.eaglerxrewindUrl = strOf(g.get("eaglerxrewindUrl"), c.eaglerxrewindUrl);
            }
            Object gw = m.get("gateway");
            if (gw instanceof Map) {
                Map<String, Object> g = (Map<String, Object>) gw;
                c.gatewayEnabled = boolOf(g.get("enabled"), true);
                c.java = strOf(g.get("java"), c.java);
                c.gatewayDir = c.gameDir.resolve(strOf(g.get("dir"), "gateway"));
                c.gatewayJar = strOf(g.get("jar"), c.gatewayJar);
                c.jvmArgs = strList(g.get("jvmArgs"), c.jvmArgs);
                c.args = strList(g.get("args"), c.args);
                c.gatewayPort = intOf(g.get("port"), c.gatewayPort);
                c.gracefulStopSec = intOf(g.get("gracefulStopSec"), c.gracefulStopSec);
            }
        }
        c.applyEnv();
        c.validate();
        return c;
    }

    void applyEnv() {
        listenPort = envInt("EAGLERD_LISTEN_PORT", listenPort);
        authToken = envStr("EAGLERD_AUTH_TOKEN", authToken);
        maxModMB = envInt("EAGLERD_MAX_MOD_MB", maxModMB);
        gatewayEnabled = envBool("EAGLERD_GATEWAY_ENABLED", gatewayEnabled);
        java = envStr("EAGLERD_JAVA", java);
        gatewayDir = Paths.get(envStr("EAGLERD_GATEWAY_DIR", gatewayDir.toString()));
        gatewayJar = envStr("EAGLERD_GATEWAY_JAR", gatewayJar);
        gatewayPort = envInt("EAGLERD_GATEWAY_PORT", gatewayPort);
        gracefulStopSec = envInt("EAGLERD_GRACEFUL_STOP_SEC", gracefulStopSec);
        String xmx = System.getenv("EAGLERD_XMX");
        if (xmx != null && !xmx.isEmpty()) {
            jvmArgs = new ArrayList<>(List.of("-Xmx" + xmx));
        }
        autoSetup = envBool("EAGLERD_AUTO_SETUP", autoSetup);
        autoFixServerProperties = envBool("EAGLERD_AUTO_FIX", autoFixServerProperties);
        backendPort = envInt("EAGLERD_BACKEND_PORT", backendPort);
        velocityVersion = envStr("EAGLERD_VELOCITY_VERSION", velocityVersion);
        velocityUrl = envStr("EAGLERD_VELOCITY_URL", velocityUrl);
        eaglerxUrl = envStr("EAGLERD_EAGLERX_URL", eaglerxUrl);
        viaVersionUrl = envStr("EAGLERD_VIAVERSION_URL", viaVersionUrl);
        viaBackwardsUrl = envStr("EAGLERD_VIABACKWARDS_URL", viaBackwardsUrl);
        viaRewindUrl = envStr("EAGLERD_VIAREWIND_URL", viaRewindUrl);
        eaglerxrewindUrl = envStr("EAGLERD_EAGLERXREWIND_URL", eaglerxrewindUrl);
        String jvm = System.getenv("EAGLERD_GATEWAY_JVM_ARGS");
        if (jvm != null && !jvm.isEmpty()) {
            jvmArgs = new ArrayList<>(List.of(jvm.split(",")));
        }
    }

    void validate() {
        if (listenPort <= 0 || listenPort > 65535) {
            throw new IllegalArgumentException("invalid listenPort " + listenPort);
        }
        if (!bridgePath.startsWith("/")) {
            throw new IllegalArgumentException("bridgePath must start with /");
        }
        if (!apiPrefix.startsWith("/")) {
            throw new IllegalArgumentException("apiPrefix must start with /");
        }
        if (gatewayEnabled) {
            if (gatewayJar == null || gatewayJar.isEmpty()) {
                throw new IllegalArgumentException("gateway.jar is required when the gateway is enabled");
            }
            if (gatewayPort <= 0 || gatewayPort > 65535 || gatewayPort == listenPort) {
                throw new IllegalArgumentException("invalid gateway port " + gatewayPort);
            }
        }
    }

    static String envStr(String k, String d) {
        String v = System.getenv(k);
        return v == null || v.isEmpty() ? d : v;
    }

    static int envInt(String k, int d) {
        try {
            String v = System.getenv(k);
            return v == null || v.isEmpty() ? d : Integer.parseInt(v);
        } catch (NumberFormatException e) {
            return d;
        }
    }

    static boolean envBool(String k, boolean d) {
        String v = System.getenv(k);
        if (v == null || v.isEmpty()) return d;
        // accept the common truthy forms; "1" must be true (Boolean.parseBoolean
        // alone returns false for it, which silently disabled autoSetup in Docker)
        return switch (v.trim().toLowerCase()) {
            case "1", "true", "yes", "on" -> true;
            case "0", "false", "no", "off" -> false;
            default -> d;
        };
    }

    static int intOf(Object v, int d) {
        return v instanceof Number n ? n.intValue() : d;
    }

    static boolean boolOf(Object v, boolean d) {
        return v instanceof Boolean b ? b : d;
    }

    static String strOf(Object v, String d) {
        return v instanceof String s ? s : d;
    }

    static List<String> strList(Object v, List<String> d) {
        if (v instanceof List<?> l) {
            List<String> out = new ArrayList<>();
            for (Object o : l) out.add(String.valueOf(o));
            return out;
        }
        return d;
    }
}
