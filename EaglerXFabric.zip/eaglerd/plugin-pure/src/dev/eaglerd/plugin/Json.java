package dev.eaglerd.plugin;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Minimal dependency-free JSON parser/writer (subset sufficient for config
 * and API payloads: objects, arrays, strings, numbers, booleans, null). */
public final class Json {
    private Json() {}

    public static Object parse(String s) {
        P p = new P(s);
        Object v = p.value();
        p.ws();
        if (p.i < s.length()) {
            throw p.err("trailing content");
        }
        return v;
    }

    @SuppressWarnings("unchecked")
    public static String write(Object v) {
        StringBuilder b = new StringBuilder();
        wr(b, v);
        return b.toString();
    }

    @SuppressWarnings("unchecked")
    static void wr(StringBuilder b, Object v) {
        if (v == null) { b.append("null"); return; }
        if (v instanceof String s) { str(b, s); return; }
        if (v instanceof Boolean bo) { b.append(bo); return; }
        if (v instanceof Number n) {
            double d = n.doubleValue();
            if (d == Math.floor(d) && !Double.isInfinite(d) && Math.abs(d) < 1e15) {
                b.append((long) d);
            } else {
                b.append(d);
            }
            return;
        }
        if (v instanceof Map) {
            Map<String, Object> m = (Map<String, Object>) v;
            b.append('{');
            boolean f = true;
            for (Map.Entry<String, Object> e : m.entrySet()) {
                if (!f) b.append(',');
                f = false;
                str(b, e.getKey());
                b.append(':');
                wr(b, e.getValue());
            }
            b.append('}');
            return;
        }
        if (v instanceof List) {
            List<Object> l = (List<Object>) v;
            b.append('[');
            boolean f = true;
            for (Object o : l) {
                if (!f) b.append(',');
                f = false;
                wr(b, o);
            }
            b.append(']');
            return;
        }
        throw new IllegalArgumentException("cannot serialize " + v.getClass());
    }

    static void str(StringBuilder b, String s) {
        b.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"' -> b.append("\\\"");
                case '\\' -> b.append("\\\\");
                case '\n' -> b.append("\\n");
                case '\r' -> b.append("\\r");
                case '\t' -> b.append("\\t");
                default -> {
                    if (c < 0x20) b.append(String.format("\\u%04x", (int) c));
                    else b.append(c);
                }
            }
        }
        b.append('"');
    }

    static final class P {
        final String s;
        int i;

        P(String s) { this.s = s; }

        void ws() { while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++; }

        Object value() {
            ws();
            if (i >= s.length()) throw err("eof");
            char c = s.charAt(i);
            switch (c) {
                case '{': return obj();
                case '[': return arr();
                case '"': return str();
                case 't': expect("true"); return Boolean.TRUE;
                case 'f': expect("false"); return Boolean.FALSE;
                case 'n': expect("null"); return null;
                default: return num();
            }
        }

        Map<String, Object> obj() {
            Map<String, Object> m = new LinkedHashMap<>();
            i++; ws();
            if (i < s.length() && s.charAt(i) == '}') { i++; return m; }
            while (true) {
                ws(); String k = str(); ws(); expect(":"); m.put(k, value()); ws();
                if (i < s.length() && s.charAt(i) == ',') { i++; continue; }
                expect("}");
                return m;
            }
        }

        List<Object> arr() {
            List<Object> l = new ArrayList<>();
            i++; ws();
            if (i < s.length() && s.charAt(i) == ']') { i++; return l; }
            while (true) {
                l.add(value()); ws();
                if (i < s.length() && s.charAt(i) == ',') { i++; continue; }
                expect("]");
                return l;
            }
        }

        String str() {
            expect("\"");
            StringBuilder b = new StringBuilder();
            while (true) {
                char c = s.charAt(i++);
                if (c == '"') return b.toString();
                if (c == '\\') {
                    char e = s.charAt(i++);
                    switch (e) {
                        case '"' -> b.append('"');
                        case '\\' -> b.append('\\');
                        case '/' -> b.append('/');
                        case 'b' -> b.append('\b');
                        case 'f' -> b.append('\f');
                        case 'n' -> b.append('\n');
                        case 'r' -> b.append('\r');
                        case 't' -> b.append('\t');
                        case 'u' -> { b.append((char) Integer.parseInt(s.substring(i, i + 4), 16)); i += 4; }
                        default -> throw err("bad escape");
                    }
                } else {
                    b.append(c);
                }
            }
        }

        Object num() {
            int j = i;
            while (j < s.length() && "+-0123456789.eE".indexOf(s.charAt(j)) >= 0) j++;
            if (j == i) throw err("bad number");
            String t = s.substring(i, j);
            i = j;
            // integral numbers keep integer identity (ids, counts, versions)
            if (t.indexOf('.') < 0 && t.indexOf('e') < 0 && t.indexOf('E') < 0) {
                try {
                    return Long.parseLong(t);
                } catch (NumberFormatException ignored) {
                }
            }
            return Double.parseDouble(t);
        }

        void expect(String w) {
            if (!s.startsWith(w, i)) throw err("expected " + w);
            i += w.length();
        }

        IllegalArgumentException err(String m) {
            return new IllegalArgumentException("json: " + m + " at " + i);
        }
    }
}
