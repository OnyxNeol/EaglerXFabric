package dev.eaglerd.plugin;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;

/**
 * The plugin's public server: Eaglercraft WebSocket bridge on bridgePath,
 * the management REST API under apiPrefix and /healthz — one port, zero
 * external HTTP dependencies (same layout as the standalone Go daemon).
 *
 * The bridge is a byte-level tunnel to the gateway's Eaglercraft WebSocket
 * listener, exactly like the extracted EaglerCMP system (manager/bridge.go):
 * no frames are parsed or translated here; Velocity + EaglerXServer owns the
 * Eaglercraft protocol.
 */
public final class EaglerdHttpServer {
    private final Config cfg;
    private final GatewaySupervisor gateway;
    private final ModsStore mods;
    private final Logger log;
    private volatile ServerSocket ss;

    public EaglerdHttpServer(Config cfg, GatewaySupervisor gateway, ModsStore mods, Logger log) {
        this.cfg = cfg;
        this.gateway = gateway;
        this.mods = mods;
        this.log = log;
    }

    public void start() throws IOException {
        // 1024 half-open connections can queue while hundreds of clients
        // join in a burst; the accept loop drains it in microseconds.
        ss = new ServerSocket(cfg.listenPort, 1024, InetAddress.getByName("0.0.0.0"));
        Thread t = new Thread(this::acceptLoop, "eaglerd-http");
        t.setDaemon(true);
        t.start();
    }

    public void stop() {
        try {
            ServerSocket s = ss;
            if (s != null) s.close();
        } catch (IOException ignored) {
        }
    }

    private void acceptLoop() {
        ServerSocket s = ss;
        while (s != null && !s.isClosed()) {
            try {
                Socket c = s.accept();
                // virtual threads (Java 21): blocking-IO relays scale to
                // hundreds of simultaneous joins without platform-thread cost
                Thread.ofVirtual().name("eaglerd-conn").start(() -> handle(c));
            } catch (IOException e) {
                return; // server socket closed
            }
        }
    }

    private void handle(Socket c) {
        try (c) {
            c.setTcpNoDelay(true);
            InputStream in = c.getInputStream();
            OutputStream out = c.getOutputStream();

            byte[] head = readHead(in);
            String headS = new String(head, StandardCharsets.ISO_8859_1);
            int sep = headS.indexOf("\r\n\r\n");
            if (sep < 0) return;
            String headerBlock = headS.substring(0, sep);
            byte[] leftover = Arrays.copyOfRange(head, sep + 4, head.length);

            String[] lines = headerBlock.split("\r\n");
            if (lines.length == 0) return;
            String[] rl = lines[0].split(" ");
            if (rl.length < 2) return;
            String method = rl[0];
            String target = rl[1];
            Map<String, String> headers = new HashMap<>();
            for (int i = 1; i < lines.length; i++) {
                int k = lines[i].indexOf(':');
                if (k > 0) headers.put(lines[i].substring(0, k).trim().toLowerCase(), lines[i].substring(k + 1).trim());
            }
            String path = target;
            String query = "";
            int q = target.indexOf('?');
            if (q >= 0) {
                path = target.substring(0, q);
                query = target.substring(q + 1);
            }
            route(c, in, out, method, path, query, headers, leftover, head);
        } catch (Exception e) {
            // per-connection failure: drop the connection
        }
    }

    private void route(Socket c, InputStream in, OutputStream out, String method, String path,
                       String query, Map<String, String> headers, byte[] leftover, byte[] head) throws Exception {
        if (path.equals("/healthz")) {
            respond(out, 200, "{\"status\":\"ok\"\n}\n");
            return;
        }
        if (path.startsWith(cfg.apiPrefix + "/") || path.equals(cfg.apiPrefix)) {
            if (!authed(headers)) {
                respond(out, 401, "{\"error\":\"missing or invalid API token\"}");
                return;
            }
            api(in, out, path.substring(cfg.apiPrefix.length()).replaceAll("^/+", ""), method, query, headers, leftover);
            return;
        }
        boolean bridge = path.equals(cfg.bridgePath)
                || (cfg.bridgePath.equals("/") && !path.equals("/favicon.ico"));
        if (bridge) {
            if ("websocket".equalsIgnoreCase(headers.get("upgrade"))) {
                bridge(c, in, head); // raw pass-through: the gateway terminates the WebSocket
            } else {
                String host = headers.getOrDefault("host", "your-server");
                respondHtml(out, landingPage(host));
            }
            return;
        }
        respond(out, 404, "{\"error\":\"not found\"}");
    }

    // ---- management API ----

    private void api(InputStream in, OutputStream out, String endpoint, String method, String query,
                     Map<String, String> headers, byte[] leftover) throws Exception {
        switch (endpoint) {
            case "status" -> respond(out, 200, Json.write(statusBody()) + "\n");
            case "restart" -> {
                if (!method.equals("POST")) { respond(out, 405, "{\"error\":\"POST required\"}"); return; }
                gateway.kick();
                respond(out, 200, "{\"status\":\"restarting\"}");
            }
            case "stop" -> {
                if (!method.equals("POST")) { respond(out, 405, "{\"error\":\"POST required\"}"); return; }
                gateway.requestStop();
                respond(out, 200, "{\"status\":\"stopping\"}");
            }
            case "start" -> {
                if (!method.equals("POST")) { respond(out, 405, "{\"error\":\"POST required\"}"); return; }
                gateway.kick();
                respond(out, 200, "{\"status\":\"starting\"}");
            }
            case "logs" -> {
                String tail = readTail(cfg.logDir.resolve("gateway.log"), 32_000);
                respond(out, 200, Json.write(Map.of("file", cfg.logDir.resolve("gateway.log").toString(),
                        "text", tail)) + "\n");
            }
            case "mods" -> modsEndpoint(in, out, method, query, headers, leftover);
            default -> respond(out, 404, "{\"error\":\"unknown endpoint\"}");
        }
    }

    private void modsEndpoint(InputStream in, OutputStream out, String method, String query,
                              Map<String, String> headers, byte[] leftover) throws Exception {
        String name = queryParams(query).get("name");
        switch (method) {
            case "GET" -> respond(out, 200, Json.write(Map.of(
                    "mods", mods.list(), "gateway", gateway.status())) + "\n");
            case "POST" -> {
                long len;
                try {
                    len = Long.parseLong(headers.getOrDefault("content-length", "0"));
                } catch (NumberFormatException e) {
                    len = 0;
                }
                long max = (long) cfg.maxModMB << 20;
                if (len > max) {
                    respond(out, 413, "{\"error\":\"mod exceeds the maximum upload size\"}");
                    return;
                }
                byte[] body = readBody(in, leftover, len);
                String err = mods.save(name, body);
                if (err != null) {
                    respond(out, 400, Json.write(Map.of("error", err)));
                    return;
                }
                respond(out, 200, Json.write(Map.of("mods", mods.list())) + "\n");
            }
            case "DELETE" -> {
                String err = mods.remove(name);
                if (err != null) {
                    respond(out, 400, Json.write(Map.of("error", err)));
                    return;
                }
                respond(out, 200, Json.write(Map.of("mods", mods.list())) + "\n");
            }
            default -> respond(out, 405, "{\"error\":\"method not allowed\"}");
        }
    }

    // ---- WebSocket bridge (byte-level tunnel to the gateway) ----

    /**
     * Raw byte pass-through, the heart of Eaglercraft integration: on seeing
     * an HTTP Upgrade handshake the plugin replays the client's exact bytes
     * (handshake included) to the gateway and then pumps raw bytes in both
     * directions. EaglerXServer terminates the WebSocket itself and speaks
     * the Eaglercraft protocol inside it — we never interpret a frame, so
     * any protocol version works unchanged. Each connection costs two
     * virtual threads, so hundreds of players joining in a burst stay
     * smooth. The REST API and status page keep sharing the same public
     * port because non-Upgrade requests are answered locally.
     */
    private void bridge(Socket c, InputStream in, byte[] raw) {
        if (cfg.gatewayEnabled && !gateway.isReady()) {
            try {
                Map<String, Object> e = new LinkedHashMap<>();
                e.put("error", "gateway is not ready");
                e.put("state", gateway.status().get("state"));
                respond(c.getOutputStream(), 503, Json.write(e) + "\n");
            } catch (IOException ignored) {
            }
            return;
        }
        try (Socket tcp = new Socket()) {
            tcp.connect(new InetSocketAddress("127.0.0.1", cfg.gatewayPort), 5000);
            tcp.setTcpNoDelay(true);
            tcp.getOutputStream().write(raw); // replay the untouched handshake
            tcp.getOutputStream().flush();
            Thread a = pump(in, tcp.getOutputStream(), tcp);
            Thread b = pump(tcp.getInputStream(), c.getOutputStream(), c);
            a.join();
            b.join();
        } catch (Exception e) {
            log.debug("bridge connection closed: {}", e.toString());
        }
    }

    private Thread pump(InputStream src, OutputStream dst, AutoCloseable close) {
        Thread t = Thread.ofVirtual().name("eaglerd-pipe").unstarted(() -> {
            byte[] buf = new byte[32768];
            try {
                int n;
                while ((n = src.read(buf)) > 0) {
                    dst.write(buf, 0, n);
                    dst.flush();
                }
            } catch (IOException ignored) {
            } finally {
                try {
                    close.close();
                } catch (Exception ignored) {
                }
            }
        });
        t.start();
        return t;
    }

    private Map<String, Object> statusBody() {
        Map<String, Object> connect = new LinkedHashMap<>();
        connect.put("eaglercraft", "ws://<host>:" + cfg.listenPort + cfg.bridgePath);
        connect.put("gateway", cfg.gatewayAddr());
        connect.put("backend", cfg.backendAddr());
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("plugin", "eaglerd-plugin");
        m.put("gateway", gateway.status());
        m.put("connect", connect);
        m.put("modsDir", cfg.modsDir.toString());
        return m;
    }

    /** Human-friendly landing page for anyone opening the port in a browser. */
    /**
     * The public face of the server: a sleek, fully transparent glass page
     * (Tailwind design language, aurora backdrop, glassmorphism surfaces).
     * Anyone who opens the server address in a browser instead of connecting
     * with a client sees server status and the exact connect address.
     */
    private String landingPage(String host) {
        String gwState = String.valueOf(gateway.status().get("state"));
        boolean ready = GatewaySupervisor.READY.equals(gwState);
        String page = """
                <!doctype html>
                <html lang="en">
                <head>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <title>eaglerd</title>
                <script src="https://cdn.tailwindcss.com"></script>
                <style>
                  body{margin:0;font-family:system-ui,-apple-system,sans-serif;background:#05070e;color:#e6e9f2;min-height:100vh}
                  .aurora{position:fixed;filter:blur(120px);opacity:.55;border-radius:9999px;z-index:0}
                  .glass{background:rgba(255,255,255,.055);border:1px solid rgba(255,255,255,.12);
                         backdrop-filter:blur(24px);-webkit-backdrop-filter:blur(24px);border-radius:1.25rem}
                  .chip{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);border-radius:.75rem}
                  .copy{background:rgba(99,102,241,.25);border:1px solid rgba(129,140,248,.45)}
                  .copy:hover{background:rgba(99,102,241,.4)}
                  .dot{width:.5rem;height:.5rem;border-radius:9999px;animation:pulse 2s infinite}
                  @keyframes pulse{0%,100%{opacity:1}50%{opacity:.35}}
                  code{font-family:ui-monospace,SFMono-Regular,Menlo,monospace}
                </style>
                </head>
                <body>
                <div class="aurora" style="width:520px;height:520px;background:#1e1b4b;top:-160px;left:-120px"></div>
                <div class="aurora" style="width:480px;height:480px;background:#042f2e;bottom:-180px;right:-100px"></div>
                <div class="aurora" style="width:360px;height:360px;background:#312e81;top:40%;left:55%;opacity:.35"></div>

                <main style="position:relative;z-index:1;display:flex;min-height:100vh;align-items:center;justify-content:center;padding:2rem">
                  <div class="glass" style="max-width:26rem;width:100%;padding:2.25rem">
                    <div style="display:flex;align-items:center;justify-content:space-between">
                      <h1 style="margin:0;font-size:1.5rem;font-weight:700;letter-spacing:-.02em">eaglerd</h1>
                      <span style="display:inline-flex;align-items:center;gap:.45rem;font-size:.8rem;padding:.3rem .7rem" class="chip">
                        <span class="dot" style="background:#34d399"></span>@@STATE@@
                      </span>
                    </div>
                    <p style="color:rgba(230,233,242,.65);font-size:.9rem;margin:.6rem 0 1.6rem">
                      Eaglercraft browser clients connect here. Java edition stays on the backend.
                    </p>

                    <div class="chip" style="padding:1rem 1.25rem">
                      <p style="margin:0 0 .4rem;font-size:.72rem;color:rgba(230,233,242,.55);text-transform:uppercase;letter-spacing:.08em">connect with eaglercraft</p>
                      <div style="display:flex;align-items:center;gap:.75rem">
                        <code id="addr" style="font-size:1.05rem;flex:1;overflow-wrap:anywhere">ws://@@HOST@@/</code>
                        <button class="copy" id="copy" style="color:#c7d2fe;font-size:.78rem;padding:.45rem .8rem;border-radius:.6rem;cursor:pointer">copy</button>
                      </div>
                    </div>

                    <div style="display:flex;gap:.6rem;margin-top:1.2rem;flex-wrap:wrap">
                      <span class="chip" style="font-size:.75rem;padding:.4rem .7rem">gateway @@GW@@</span>
                      <span class="chip" style="font-size:.75rem;padding:.4rem .7rem">fabric @@BE@@</span>
                      <span class="chip" style="font-size:.75rem;padding:.4rem .7rem">eaglerxserver</span>
                    </div>

                    <p style="color:rgba(230,233,242,.45);font-size:.75rem;margin:1.6rem 0 0;border-top:1px solid rgba(255,255,255,.09);padding-top:1rem">
                      Server owner: manage mods, logs and the gateway at <code>@@API@@/status</code> (X-Api-Token header).
                    </p>
                  </div>
                </main>

                <script>
                  document.getElementById('copy').onclick = function() {
                    navigator.clipboard.writeText(document.getElementById('addr').textContent);
                    var b = this; b.textContent = 'copied'; setTimeout(function() { b.textContent = 'copy'; }, 1200);
                  };
                </script>
                </body></html>
                """;
        return page.replace("@@STATE@@", ready ? "ready" : gwState)
                .replace("@@HOST@@", host)
                .replace("@@GW@@", cfg.gatewayAddr())
                .replace("@@BE@@", cfg.backendAddr())
                .replace("@@API@@", cfg.apiPrefix);
    }

    private void respondHtml(OutputStream out, String body) throws IOException {
        byte[] b = body.getBytes(StandardCharsets.UTF_8);
        out.write(("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nCache-Control: no-store\r\n"
                + "Content-Length: " + b.length + "\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.UTF_8));
        out.write(b);
        out.flush();
    }

    // ---- helpers ----

    private boolean authed(Map<String, String> headers) {
        if (cfg.authToken.isEmpty()) return true;
        String tok = headers.get("x-api-token");
        if (tok == null) {
            String auth = headers.get("authorization");
            if (auth != null && auth.startsWith("Bearer ")) tok = auth.substring(7);
        }
        return tok != null && tok.equals(cfg.authToken);
    }

    private static Map<String, String> queryParams(String query) {
        Map<String, String> m = new HashMap<>();
        if (query == null || query.isEmpty()) return m;
        for (String kv : query.split("&")) {
            int i = kv.indexOf('=');
            if (i > 0) m.put(urlDecode(kv.substring(0, i)), urlDecode(kv.substring(i + 1)));
        }
        return m;
    }

    private static String urlDecode(String s) {
        return java.net.URLDecoder.decode(s, StandardCharsets.UTF_8);
    }

    private void respond(OutputStream out, int code, String body) throws IOException {
        byte[] b = body.getBytes(StandardCharsets.UTF_8);
        String reason = switch (code) {
            case 200 -> "OK";
            case 401 -> "Unauthorized";
            case 403 -> "Forbidden";
            case 404 -> "Not Found";
            case 405 -> "Method Not Allowed";
            case 413 -> "Payload Too Large";
            case 503 -> "Service Unavailable";
            default -> "Error";
        };
        out.write(("HTTP/1.1 " + code + " " + reason + "\r\nContent-Type: application/json\r\nCache-Control: no-store\r\n"
                + "Content-Length: " + b.length + "\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.UTF_8));
        out.write(b);
        out.flush();
    }

    private byte[] readHead(InputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        int[] window = {0, 0, 0, 0};
        while (true) {
            int r = in.read();
            if (r < 0) break;
            b.write(r);
            window[0] = window[1];
            window[1] = window[2];
            window[2] = window[3];
            window[3] = r;
            if (window[0] == '\r' && window[1] == '\n' && window[2] == '\r' && window[3] == '\n') break;
            if (b.size() > 65536) break;
        }
        return b.toByteArray();
    }

    private byte[] readBody(InputStream in, byte[] leftover, long len) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        b.write(leftover, 0, (int) Math.min(leftover.length, len));
        while (b.size() < len) {
            int n = in.read();
            if (n < 0) break;
            b.write(n);
        }
        return b.toByteArray();
    }

    private String readTail(java.nio.file.Path file, int bytes) {
        try {
            byte[] data = java.nio.file.Files.readAllBytes(file);
            int from = Math.max(0, data.length - bytes);
            return new String(data, from, data.length - from, StandardCharsets.UTF_8);
        } catch (IOException e) {
            return "(no log yet)";
        }
    }
}
