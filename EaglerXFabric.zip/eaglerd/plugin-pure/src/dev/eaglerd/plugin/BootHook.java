package dev.eaglerd.plugin;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Fabric "main" entrypoint: runs before the dedicated server reads
 * server.properties, so a fresh server boots straight into the right
 * topology (backend on 127.0.0.1:25566, eaglerd owning the public port)
 * on the very first start — no restart needed. ModInitializer#onInitialize
 * runs too late for that: Minecraft parses server.properties before it.
 */
public class BootHook implements net.fabricmc.api.ModInitializer {
    private static final Logger LOG = LoggerFactory.getLogger("eaglerd-boot");

    @Override
    public void onInitialize() {
        try {
            Path gameDir = Paths.get(System.getProperty("user.dir"));
            if (!Files.isDirectory(gameDir.resolve("mods"))) {
                return; // not a server directory; do nothing
            }
            Config cfg = Config.load(gameDir.resolve("eaglerd-plugin.json"));
            if (cfg.autoSetup && cfg.autoFixServerProperties) {
                String changes = ServerProperties.fix(cfg, LOG);
                if (changes != null) {
                    LOG.info("server.properties fixed for Eaglercraft (pre-boot): {}", changes);
                }
            }
        } catch (Exception e) {
            LOG.warn("early server.properties fix skipped: {}", e.toString());
        }
    }
}
