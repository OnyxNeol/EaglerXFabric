#!/usr/bin/env python3
"""First-boot UX regression for the independent eaglerd-plugin jar.

Simulates the laziest possible user: empty directory, a server.properties
with the classic mistakes, no config. The plugin must:
  1. create a ready default config with a generated API token
  2. fix server.properties (backup + port/online-mode/server-ip)
  3. auto-provision gateway/ (velocity.jar + 3 plugin jars + velocity.toml)
     from pinned mirror URLs (local HTTP server stands in for the internet)
  4. supervise the gateway, bridge Eaglercraft WS traffic, serve a friendly
     landing page, accept mod uploads, restart cleanly, and shut down
     gracefully on SIGTERM with zero orphan processes.
"""
import base64
import hashlib
import json
import os
import signal
import socket
import subprocess
import threading
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer

EAGLERD = "/app/conversations/6ad32a084ce18c326740c5a2/eaglerd"
JAR = f"{EAGLERD}/dist/eaglerd-plugin-1.2.0.jar"
GAME = "/tmp/plugin-test2"
PORT, GW_PORT, MIRROR = 18080, 18082, 18085
FAKE_JAR = b"PK\x03\x04" + b"M" * 512


def api(path, method="GET", token=None, data=None):
    req = urllib.request.Request(f"http://127.0.0.1:{PORT}{path}", method=method, data=data)
    if token:
        req.add_header("X-Api-Token", token)
    try:
        with urllib.request.urlopen(req, timeout=5) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read())


class Mirror(BaseHTTPRequestHandler):
    def do_GET(self):
        name = self.path.lstrip("/")
        if name in ("velocity.jar", "eaglerxserver-1.2.jar", "viaversion-5.jar", "viabackwards-5.jar", "viarewind-4.jar", "eaglerxrewind.jar"):
            self.send_response(200)
            self.send_header("Content-Length", str(len(FAKE_JAR)))
            self.end_headers()
            self.wfile.write(FAKE_JAR)
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, *a):
        pass


def kill_stale(exclude_self=True):
    me = str(os.getpid())
    for pid in os.listdir("/proc"):
        if not pid.isdigit() or (exclude_self and pid == me):
            continue
        try:
            cmd = open(f"/proc/{pid}/cmdline", "rb").read().decode(errors="replace")
        except OSError:
            continue
        if "Eaglerd" + "Plugin" in cmd or "jvm" + "gw" in cmd or ("test_" + "plugin.py" in cmd and pid != me):
            try:
                os.kill(int(pid), 9)
            except OSError:
                pass


def cleanup():
    kill_stale()
    time.sleep(1)


def main():
    subprocess.run(["rm", "-rf", GAME])
    os.makedirs(f"{GAME}/mods", exist_ok=True)
    os.chdir(GAME)
    # classic first-boot mistakes: public port clash, online mode, exposed IP
    open(f"{GAME}/server.properties", "w").write(
        "server-port=%d\nonline-mode=true\nenforce-secure-profile=true\nmotd=hi\n" % PORT)

    class MirrorServer(HTTPServer):
        allow_reuse_address = True
    srv = MirrorServer(("127.0.0.1", MIRROR), Mirror)
    threading.Thread(target=srv.serve_forever, daemon=True).start()

    cleanup()
    env = dict(os.environ,
               EAGLERD_JAVA="/tmp/fakebin/java",
               EAGLERD_LISTEN_PORT=str(PORT),
               EAGLERD_GATEWAY_PORT=str(GW_PORT),
               EAGLERD_VELOCITY_URL=f"http://127.0.0.1:{MIRROR}/velocity.jar",
               EAGLERD_EAGLERX_URL=f"http://127.0.0.1:{MIRROR}/eaglerxserver-1.2.jar",
               EAGLERD_VIAVERSION_URL=f"http://127.0.0.1:{MIRROR}/viaversion-5.jar",
               EAGLERD_VIAREWIND_URL=f"http://127.0.0.1:{MIRROR}/viarewind-4.jar",
               EAGLERD_EAGLERXREWIND_URL=f"http://127.0.0.1:{MIRROR}/eaglerxrewind.jar",
               EAGLERD_VIABACKWARDS_URL=f"http://127.0.0.1:{MIRROR}/viabackwards-5.jar")
    proc = subprocess.Popen([
        "/opt/jdk/bin/java",
        "-cp", f"{JAR}:{EAGLERD}/vendor-jars/fabric-loader.jar:{EAGLERD}/vendor-jars/slf4j-api.jar:{EAGLERD}/vendor-jars/slf4j-simple.jar",
        "dev.eaglerd.plugin.Eaglerd" + "Plugin",  # split: cleanup patterns never match us
    ], env=env, stdout=open("plugin.out", "w"), stderr=subprocess.STDOUT)
    try:
        # 1. default config created with a token
        token = None
        for _ in range(20):
            time.sleep(0.5)
            if os.path.exists(f"{GAME}/eaglerd-plugin.json"):
                cfg = json.loads(open(f"{GAME}/eaglerd-plugin.json").read())
                token = cfg["authToken"]
                assert token and len(token) >= 20, cfg
                break
        assert token, "default config was never written"
        print("1. default config created, token generated:", token[:8] + "...")

        # 2. gateway becomes ready via auto-provisioned gateway/
        st = None
        for _ in range(40):
            time.sleep(0.5)
            try:
                code, st = api("/api/status", token=token)
                if st["gateway"]["state"] == "ready":
                    break
            except Exception:
                pass
        else:
            print("FAIL: gateway never became ready")
            print(open("plugin.out").read())
            return 1
        print("2. gateway ready:", json.dumps(st["gateway"]))
        assert st["connect"]["eaglercraft"].endswith(f":{PORT}/"), st["connect"]

        # 3. server.properties fixed with backup
        props = open(f"{GAME}/server.properties").read()
        bak = open(f"{GAME}/server.properties.eaglerd.bak").read()
        assert "server-port=25566" in props, props
        assert "online-mode=false" in props, props
        assert "server-ip=127.0.0.1" in props, props
        assert f"server-port={PORT}" in bak, bak
        print("3. server.properties auto-fixed (backup kept)")

        # 4. gateway auto-provisioned
        gw = f"{GAME}/gateway"
        assert open(f"{gw}/velocity.toml").read().count("127.0.0.1:25566") == 1
        assert os.path.getsize(f"{gw}/velocity.jar") == len(FAKE_JAR)
        for p in ("eaglerxserver-1.2.jar", "viaversion-5.jar", "viabackwards-5.jar", "viarewind-4.jar", "eaglerxrewind.jar"):
            assert os.path.exists(f"{gw}/plugins/{p}"), p
        vt = open(f"{gw}/velocity.toml").read()
        assert "online-mode = false" in vt, "velocity.toml must disable online-mode for Eaglercraft"
        lt = open(f"{gw}/plugins/eaglerxserver/listeners.toml").read()
        assert 'inject_address = "127.0.0.1:18082"' in lt, lt
        print("4. gateway auto-provisioned: velocity.toml(online-mode=false) + velocity.jar + 5 plugins (rewind included) + listeners.toml")

        # 5. auth enforced + landing page friendly
        code, _ = api("/api/status", token=None)
        assert code == 401
        with urllib.request.urlopen(f"http://127.0.0.1:{PORT}/", timeout=5) as r:
            page = r.read().decode()
        assert "eaglerd" in page.lower() and "ready" in page and "text/html" in r.headers["Content-Type"]
        print("5. auth (401) + friendly HTML landing page OK")

        # 6. mod upload: non-jar rejected, real zip accepted, delete works
        code, r = api("/api/mods?name=evil.jar", method="POST", token=token, data=b"not a zip")
        assert code == 400 and "zip signature" in r["error"], (code, r)
        code, r = api("/api/mods?name=bad%2Fname.jar", method="POST", token=token, data=b"PK\x03\x04")
        assert code == 400 and "invalid file name" in r["error"], (code, r)
        import zipfile
        with zipfile.ZipFile("/tmp/mymod.jar", "w") as z:
            z.writestr("fabric.mod.json", '{"id":"mymod"}')
        code, r = api("/api/mods?name=mymod.jar", method="POST", token=token,
                      data=open("/tmp/mymod.jar", "rb").read())
        assert code == 200 and any(m["name"] == "mymod.jar" for m in r["mods"]), (code, r)
        assert os.path.exists(f"{GAME}/mods/mymod.jar")
        code, r = api("/api/mods?name=mymod.jar", method="DELETE", token=token)
        assert code == 200 and r["mods"] == [], (code, r)
        print("6. mod upload/reject/delete OK")

        # 7. raw pass-through: the GATEWAY must terminate the WebSocket.
        #    If our relayed handshake bytes were altered even by one byte,
        #    Sec-WebSocket-Accept would not match what the client expects.
        s = socket.create_connection(("127.0.0.1", PORT), timeout=5)
        key = base64.b64encode(os.urandom(16)).decode()
        s.sendall((f"GET / HTTP/1.1\r\nHost: localhost\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                   f"Sec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n").encode())
        expected = base64.b64encode(hashlib.sha1((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode()).digest())
        resp = b""
        while b"\r\n\r\n" not in resp:
            resp += s.recv(2048)
        head, buf = resp.split(b"\r\n\r\n", 1)
        assert b"101" in head.split(b"\r\n")[0], head
        got = [l for l in head.split(b"\r\n") if l.lower().startswith(b"sec-websocket-accept:")][0].split(b":", 1)[1].strip()
        assert got == expected, (got, expected)  # handshake survived byte-for-byte
        print("7. handshake passed through intact (accept key verified)")
        buf = buf if isinstance(buf, bytes) else buf

        def rf():
            nonlocal buf
            while len(buf) < 2:
                buf += s.recv(4096)
            ln = buf[1] & 0x7F
            while len(buf) < 2 + ln:
                buf += s.recv(4096)
            payload, buf = buf[2:2 + ln], buf[2 + ln:]
            return payload

        greeting = rf().decode().strip()
        print("   frame 1 (gateway greeting):", greeting)
        assert greeting == "FAKE-EAGLERCRAFT-LISTENER", greeting
        p = b"CLIENT-FRAME"
        m = os.urandom(4)
        s.sendall(bytes([0x82, 0x80 | len(p)]) + m + bytes(b ^ m[i % 4] for i, b in enumerate(p)))
        echo = rf().decode()
        print("   frame 2 (gateway echo):   ", echo)
        assert echo == "GATEWAY-ECHO:" + "CLIENT-FRAME", echo

        # 8. restart endpoint gives the gateway a new pid
        old_pid = st["gateway"]["pid"]
        api("/api/restart", method="POST", token=token)
        for _ in range(40):
            time.sleep(0.5)
            code, st = api("/api/status", token=token)
            if st["gateway"]["state"] == "ready" and st["gateway"]["pid"] != old_pid:
                break
        assert st["gateway"]["pid"] != old_pid, st
        print("8. restart OK: pid", old_pid, "->", st["gateway"]["pid"])

        # 9. SIGTERM: graceful gateway stop, zero orphans
        proc.send_signal(signal.SIGTERM)
        deadline = time.time() + 25
        while time.time() < deadline and proc.poll() is None:
            time.sleep(0.5)
        time.sleep(2)
        alive = subprocess.run(["pgrep", "-f", "jvm" + "gw"], capture_output=True).returncode == 0
        assert not alive, "gateway survived server shutdown"
        print("9. graceful shutdown, no orphan processes")
        print("ALL-FIRST-BOOT-TESTS-PASSED")
        return 0
    finally:
        if proc.poll() is None:
            proc.kill()
        srv.shutdown()


if __name__ == "__main__":
    raise SystemExit(main())
