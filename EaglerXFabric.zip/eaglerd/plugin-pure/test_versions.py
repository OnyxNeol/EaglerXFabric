#!/usr/bin/env python3
"""Eaglercraft client version matrix: verifies that every client version
listed on eaglercraft.com can join through the eaglerd plugin:

  - EaglercraftX 1.8.8  (MC protocol 47,  eagler handshake v4)
  - Eaglercraft 1.12.2  (MC protocol 340, eagler handshake v4)
  - Eaglercraft 26.2 "zeus" (MC protocol 776, eagler handshake v5)
  - Eaglercraft 1.5.2   (legacy rewind protocol 69)

Each connects to the plugin, performs that version's login handshake, and
the Fabric backend log must show the join.
"""
import base64
import os
import socket
import struct
import sys
import time

HOST, PORT = "127.0.0.1", 25565


def u8(v):
    return struct.pack(">B", v)


def u16(v):
    return struct.pack(">H", v)


def legacy_str(s):
    # legacy MC string: u16 length + 2-byte (big-endian UTF-16) chars
    return u16(len(s)) + s.encode("utf-16-be")


def connect():
    s = socket.create_connection((HOST, PORT), timeout=10)
    s.settimeout(10)
    key = base64.b64encode(os.urandom(16)).decode()
    s.sendall((f"GET / HTTP/1.1\r\nHost: {HOST}\r\nUpgrade: websocket\r\n"
              f"Connection: Upgrade\r\nSec-WebSocket-Key: {key}\r\n"
              f"Sec-WebSocket-Version: 13\r\n\r\n").encode())
    resp = b""
    while b"\r\n\r\n" not in resp:
        resp += s.recv(4096)
    assert b"101" in resp.split(b"\r\n")[0], resp[:120]
    return s, resp.split(b"\r\n\r\n", 1)[1]


def send(s, payload):
    m = os.urandom(4)
    masked = bytes(b ^ m[i % 4] for i, b in enumerate(payload))
    ln = len(payload)
    if ln < 126:
        hdr = bytes([0x82, 0x80 | ln])
    else:
        hdr = bytes([0x82, 0x80 | 126]) + struct.pack(">H", ln)
    s.sendall(hdr + m + masked)


def recv(s, buf, timeout=15):
    s.settimeout(timeout)
    while len(buf) < 2:
        buf += s.recv(4096)
    ln = buf[1] & 0x7F
    if ln == 126:
        while len(buf) < 4:
            buf += s.recv(4096)
        ln = struct.unpack(">H", buf[2:4])[0]
        off = 4
    else:
        off = 2
    while len(buf) < off + ln:
        buf += s.recv(4096)
    return buf[off:off + ln], buf[off + ln:]


def drain(s, buf, seconds=4):
    """Collect frames until the wall-clock budget runs out."""
    end = time.time() + seconds
    out = []
    while time.time() < end:
        try:
            f, buf = recv(s, buf, timeout=max(0.2, end - time.time()))
            out.append(f)
        except (socket.timeout, OSError):
            break
    return out


def eaglerx_login(username, mc_proto, eagler_proto):
    """EaglercraftX-style login (1.8.8 / 1.12.2 / 26.2)."""
    s, buf = connect()
    # packet 0x01: [1, 2, eagler protos, mc protos, brand, version, auth, user]
    p = u8(0x01) + u8(2) + u16(1) + u16(eagler_proto) + u16(1) + u16(mc_proto)
    p += u8(12) + b"EaglercraftX" + u8(5) + b"1.8.8" + u8(0)
    p += u8(len(username)) + username.encode()
    send(s, p)
    f, buf = recv(s, buf)
    assert f[0] == 0x02, f"expected SERVER_VERSION, got 0x{f[0]:02X} {f[:24].hex()}"
    print(f"    0x02 SERVER_VERSION: eagler v{struct.unpack('>H', f[1:3])[0]}, "
          f"mc {struct.unpack('>H', f[3:5])[0]}")

    # packet 0x04 REQUEST_LOGIN (V4 base; V5 appends caps varint + ext byte)
    p = u8(0x04) + u8(len(username)) + username.encode() + u8(0) + u8(0) + u8(0) + u8(0)
    if eagler_proto >= 5:
        p += b"\x00" + u8(0)   # standardCaps varint 0, extCapabilities 0
    send(s, p)
    f, buf = recv(s, buf)
    if f[0] == 0xFF:
        return s, buf, f"ERROR packet: {f[1:].decode(errors='replace')}"
    assert f[0] == 0x05, f"expected ALLOW_LOGIN, got 0x{f[0]:02X} {f[:24].hex()}"

    send(s, u8(0x07) + u8(0))   # PROFILE_DATA: none
    send(s, u8(0x08))           # FINISH_LOGIN
    time.sleep(2)
    frames = drain(s, buf, 4)
    ids = [f"[0x{f[0]:02X}]" for f in frames[:8]]
    return s, b"", "joined; game packets: " + " ".join(ids)


def rewind_login(username):
    """Eaglercraft 1.5.2 rewind: handshake [2,69,user,host,port], then the
    legacy login dance (Packet252SharedKey -> Packet205ClientCommand)."""
    s, buf = connect()
    p = u8(2) + u8(69) + legacy_str(username) + legacy_str("127.0.0.1") + struct.pack(">i", 25565)
    send(s, p)
    # EaglerXRewind emulates the V5 handshake internally, then answers with
    # Packet252SharedKey (0xFC); the client replies ClientCommand(0) (0xCD).
    f, buf = recv(s, buf, timeout=20)
    if f[0] != 0xFC:
        return s, b"", f"expected Packet252SharedKey, got 0x{f[0]:02X} {f[:24].hex()}"
    send(s, u8(0xCD) + u8(0))
    time.sleep(2)
    frames = drain(s, buf, 4)
    return s, b"", ("rewind login dance complete (shared key + client command accepted; "
                    f"{len(frames)} follow-up frame(s))")


def main():
    cases = [
        ("Eagler18", 47, 4),      # EaglercraftX 1.8.8
        ("Eagler112", 340, 4),     # Eaglercraft 1.12.2
        ("Eagler262", 776, 5),     # Eaglercraft 26.2 "zeus"
    ]
    for name, proto, ep in cases:
        print(f"[{name}] MC protocol {proto}, eagler v{ep}:")
        try:
            s, buf, msg = eaglerx_login(name, proto, ep)
            print("    " + msg)
            s.close()
        except Exception as e:
            print(f"    FAILED: {e}")
    print("[Eagler152] rewind protocol 69 (Eaglercraft 1.5.2):")
    try:
        s, buf, msg = rewind_login("Eagler152")
        print("    " + msg)
        s.close()
    except Exception as e:
        print(f"    FAILED: {e}")


if __name__ == "__main__":
    raise SystemExit(main())
