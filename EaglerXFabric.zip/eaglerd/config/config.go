// Package config loads eaglerd configuration from a JSON file and applies
// EAGLERD_* environment variable overrides, so the same deployment works for
// a systemd service, a Docker container and a Pterodactyl server.
//
// The Backend/Gateway split is carried over from the extracted EaglerCMP
// system (eaglercmp/config/config.go): the Fabric game server JVM ("backend")
// and the Eaglercraft protocol gateway JVM (Velocity + EaglerXServer,
// "gateway") are supervised by the same code path.
package config

import (
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"os"
	"strconv"
	"strings"
)

// Backend configures one JVM process supervised by eaglerd, used for both
// the Fabric game server (default port 25566) and the Eaglercraft gateway
// (Velocity + EaglerXServer, default port 25577, the Eaglercraft WebSocket
// listener that forwards standard Minecraft packets to Fabric).
type Backend struct {
	Enabled bool `json:"enabled"`
	// Java is the java binary to run; defaults to "java".
	Java string `json:"java,omitempty"`
	// Dir is the server working directory (world, mods/, jar).
	Dir string `json:"dir,omitempty"`
	// Jar is the launcher jar relative to Dir, e.g. fabric-server-launch.jar.
	Jar string `json:"jar,omitempty"`
	// JVMArgs are passed before -jar, e.g. ["-Xmx2G"].
	JVMArgs []string `json:"jvmArgs,omitempty"`
	// Args are passed after the jar; defaults to ["nogui"].
	Args []string `json:"args,omitempty"`
	// Port is the loopback TCP port the process listens on.
	Port int `json:"port,omitempty"`
	// GracefulStopSec: how long to wait after writing "stop" to the server
	// console before escalating to SIGINT/SIGKILL. Default 20.
	GracefulStopSec int `json:"gracefulStopSec,omitempty"`
}

// EffPort returns the configured port or the given default.
func (b Backend) EffPort(def int) int {
	if b.Port != 0 {
		return b.Port
	}
	return def
}

// Config is the top-level eaglerd configuration (eaglerd.json).
type Config struct {
	// ListenPort is the public HTTP/WebSocket port eaglerd binds to.
	// Eaglercraft clients connect to wss://host:<ListenPort><BridgePath>.
	ListenPort int `json:"listenPort"`
	// BridgePath is the WebSocket endpoint tunneled to the gateway/backend.
	// Default "/".
	BridgePath string `json:"bridgePath"`
	// APIPrefix is where the JSON management API lives, e.g. "/api".
	APIPrefix string `json:"apiPrefix"`
	// AuthToken, when set, is required on all /api calls via the
	// X-Api-Token header (or Authorization: Bearer <token>).
	AuthToken string `json:"authToken,omitempty"`
	// MaxModMB limits uploaded mod size. Default 256.
	MaxModMB int `json:"maxModMB,omitempty"`
	// AllowedOrigins restricts WebSocket origins. Empty means allow all
	// (Eaglercraft web clients embed arbitrary origins; the Java-side
	// gateway applies its own origin checks).
	AllowedOrigins []string `json:"allowedOrigins,omitempty"`
	// LogDir is where backend/gateway console logs are appended.
	LogDir string `json:"logDir,omitempty"`
	// Backend is the Fabric game server JVM.
	Backend Backend `json:"backend"`
	// Gateway is the optional Velocity + EaglerXServer JVM in front of
	// Backend: the browser's WebSocket tunnel ends here, and the gateway
	// forwards standard Minecraft packets to the Fabric server.
	Gateway *Backend `json:"gateway,omitempty"`
}

// FileName is the default on-disk config file name.
const FileName = "eaglerd.json"

// Default returns the configuration used when no file exists, mirroring the
// stack provisioned by setup.sh (extracted from EaglerCMP's setup-local-stack.sh).
func Default() *Config {
	return &Config{
		ListenPort: 25565,
		BridgePath: "/",
		APIPrefix:  "/api",
		MaxModMB:   256,
		LogDir:     "logs",
		Backend: Backend{
			Enabled: true,
			Java:    "java",
			Dir:     "backend",
			Jar:     "fabric-server-launch.jar",
			JVMArgs: []string{"-Xmx2G"},
			Port:    25566,
		},
		Gateway: &Backend{
			Enabled: true,
			Java:    "java",
			Dir:     "gateway",
			Jar:     "velocity.jar",
			JVMArgs: []string{"-Xmx512M"},
			Args:    []string{},
			Port:    25577,
		},
	}
}

// Load reads the config at path, creating it with defaults when missing,
// then applies EAGLERD_* environment overrides and validates the result.
func Load(path string) (*Config, error) {
	data, err := os.ReadFile(path)
	if errors.Is(err, fs.ErrNotExist) {
		cfg := Default()
		ApplyEnv(cfg)
		return cfg, cfg.Validate()
	}
	if err != nil {
		return nil, err
	}
	cfg := Default()
	if err := json.Unmarshal(data, cfg); err != nil {
		return nil, fmt.Errorf("parse %s: %w", path, err)
	}
	ApplyEnv(cfg)
	return cfg, cfg.Validate()
}

// ApplyEnv overrides config values from environment variables so containers
// and hosting panels can configure eaglerd without editing files.
func ApplyEnv(c *Config) {
	envInt("EAGLERD_LISTEN_PORT", &c.ListenPort)
	envStr("EAGLERD_BRIDGE_PATH", &c.BridgePath)
	envStr("EAGLERD_API_PREFIX", &c.APIPrefix)
	envStr("EAGLERD_AUTH_TOKEN", &c.AuthToken)
	envInt("EAGLERD_MAX_MOD_MB", &c.MaxModMB)
	envStr("EAGLERD_LOG_DIR", &c.LogDir)
	if v := os.Getenv("EAGLERD_ALLOWED_ORIGINS"); v != "" {
		c.AllowedOrigins = strings.Split(v, ",")
	}

	envBool("EAGLERD_BACKEND_ENABLED", &c.Backend.Enabled)
	envStr("EAGLERD_JAVA", &c.Backend.Java)
	envStr("EAGLERD_BACKEND_DIR", &c.Backend.Dir)
	envStr("EAGLERD_JAR", &c.Backend.Jar)
	envInt("EAGLERD_BACKEND_PORT", &c.Backend.Port)
	envList("EAGLERD_JVM_ARGS", &c.Backend.JVMArgs)
	// EAGLERD_XMX=4G is a panel-friendly shortcut for -Xmx4G.
	if x := os.Getenv("EAGLERD_XMX"); x != "" {
		c.Backend.JVMArgs = append([]string{"-Xmx" + x}, c.Backend.JVMArgs...)
	}

	if c.Gateway != nil {
		envBool("EAGLERD_GATEWAY_ENABLED", &c.Gateway.Enabled)
		envStr("EAGLERD_GATEWAY_DIR", &c.Gateway.Dir)
		envStr("EAGLERD_GATEWAY_JAR", &c.Gateway.Jar)
		envInt("EAGLERD_GATEWAY_PORT", &c.Gateway.Port)
		envList("EAGLERD_GATEWAY_JVM_ARGS", &c.Gateway.JVMArgs)
	}
}

// Validate rejects configurations that cannot launch cleanly.
func (c *Config) Validate() error {
	if c.ListenPort <= 0 || c.ListenPort > 65535 {
		return fmt.Errorf("invalid listenPort %d", c.ListenPort)
	}
	if !strings.HasPrefix(c.BridgePath, "/") {
		return fmt.Errorf("bridgePath %q must start with /", c.BridgePath)
	}
	if !strings.HasPrefix(c.APIPrefix, "/") {
		return fmt.Errorf("apiPrefix %q must start with /", c.APIPrefix)
	}
	if c.Backend.Enabled {
		if err := validateJar("backend", c.Backend.Jar); err != nil {
			return err
		}
		if p := c.Backend.EffPort(25566); p <= 0 || p > 65535 || p == c.ListenPort {
			return fmt.Errorf("invalid backend port %d (must differ from listenPort %d)", p, c.ListenPort)
		}
	}
	if c.Gateway != nil && c.Gateway.Enabled {
		if err := validateJar("gateway", c.Gateway.Jar); err != nil {
			return err
		}
		if p := c.Gateway.EffPort(25577); p <= 0 || p > 65535 || p == c.ListenPort {
			return fmt.Errorf("invalid gateway port %d (must differ from listenPort %d)", p, c.ListenPort)
		}
		// Gateway-only mode is allowed: the Fabric server may run outside
		// the daemon (the eaglerd fabric-loader mod, or a panel-managed
		// server). Velocity forwards to whatever velocity.toml points at.
		if c.Gateway.EffPort(25577) == c.Backend.EffPort(25566) {
			return fmt.Errorf("backend.port and gateway.port must differ")
		}
	}
	return nil
}

func validateJar(name, jar string) error {
	if jar == "" {
		return fmt.Errorf("%s.jar is required when %s is enabled", name, name)
	}
	if !strings.HasSuffix(strings.ToLower(jar), ".jar") || strings.HasPrefix(jar, "/") || strings.Contains(jar, "..") {
		return fmt.Errorf("%s.jar %q must be a .jar path relative to its directory", name, jar)
	}
	return nil
}

func envStr(key string, dst *string) {
	if v := os.Getenv(key); v != "" {
		*dst = v
	}
}

func envInt(key string, dst *int) {
	if v := os.Getenv(key); v != "" {
		if n, err := strconv.Atoi(v); err == nil {
			*dst = n
		}
	}
}

func envBool(key string, dst *bool) {
	if v := os.Getenv(key); v != "" {
		if b, err := strconv.ParseBool(v); err == nil {
			*dst = b
		}
	}
}

func envList(key string, dst *[]string) {
	if v := os.Getenv(key); v != "" {
		*dst = strings.Split(v, ",")
	}
}
