// eaglerd: an Eaglercraft WebSocket gateway daemon with integrated Fabric
// JVM process management, designed for Linux VPS, cloud nodes and hosting
// panels (Pterodactyl, Docker, systemd).
//
// Architecture (carried over from the system extracted from EaglerCMP):
//
//	Eaglercraft browser client
//	   -> WebSocket to eaglerd (public port, e.g. wss://host:25565/)
//	   -> gateway JVM: Velocity + EaglerXServer + ViaVersion/ViaBackwards
//	      (Eaglercraft protocol -> standard Minecraft packets)
//	   -> backend JVM: Fabric server with .jar mods in backend/mods/
//
// eaglerd supervises both JVMs, ingests mods over a REST API, bridges the
// WebSocket byte-for-byte to the gateway's Eaglercraft listener, and reports
// state and resource usage.
package main

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"log"
	"net"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"eaglerd/api"
	"eaglerd/bridge"
	"eaglerd/config"
	"eaglerd/mods"
	"eaglerd/supervisor"
)

func main() {
	cfgPath := flag.String("config", config.FileName, "path to the eaglerd JSON config")
	flag.Parse()

	lg := log.New(os.Stdout, "eaglerd ", log.LstdFlags|log.Lmicroseconds)
	cfg, err := config.Load(*cfgPath)
	if err != nil {
		lg.Fatalf("config: %v", err)
	}

	rootCtx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	// Supervised JVMs: Fabric backend (25566) and, when enabled, the
	// Velocity + EaglerXServer gateway (25577).
	be := supervisor.NewBackend("backend", 25566, cfg.Backend, cfg.LogDir, lg)
	go be.Run(rootCtx)

	var gw *supervisor.Backend
	if cfg.Gateway != nil {
		gw = supervisor.NewBackend("gateway", 25577, *cfg.Gateway, cfg.LogDir, lg)
		go gw.Run(rootCtx)
	}

	// WebSocket tunnel target: with a gateway the browser's WebSocket ends
	// there; without one the backend itself must speak Eaglercraft.
	target := be
	if gw != nil && gw.Cfg.Enabled {
		target = gw
	}

	m := &mods.Mods{Backend: be, MaxBytes: int64(cfg.MaxModMB) << 20}
	if m.MaxBytes <= 0 {
		m.MaxBytes = mods.MaxModSize
	}

	mux := http.NewServeMux()
	mux.Handle(cfg.BridgePath, &bridge.Bridge{Target: target, AllowedOrigins: cfg.AllowedOrigins})
	mux.Handle(cfg.APIPrefix+"/", &api.API{Backend: be, Gateway: gw, Mods: m, Cfg: cfg})
	mux.HandleFunc("/healthz", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.Write([]byte(`{"status":"ok"}` + "\n"))
	})

	srv := &http.Server{
		Addr:              fmt.Sprintf("0.0.0.0:%d", cfg.ListenPort),
		Handler:           mux,
		ReadHeaderTimeout: 15 * time.Second,
		// No ReadTimeout/WriteTimeout: game WebSockets stay open for hours.
	}

	ln, err := net.Listen("tcp", srv.Addr)
	if err != nil {
		lg.Fatalf("listen: %v", err)
	}
	go func() {
		<-rootCtx.Done()
		lg.Printf("shutting down (draining %ds)", 30)
		ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
		defer cancel()
		srv.Shutdown(ctx) // in-flight bridges drain; supervisor stops JVMs gracefully
	}()

	lg.Printf("listening on %s | bridge: ws://<host>:%d%s | api: %s/ | mods dir: %s",
		srv.Addr, cfg.ListenPort, cfg.BridgePath, cfg.APIPrefix, be.ModsDir())
	if gw != nil && gw.Cfg.Enabled {
		if cfg.Backend.Enabled {
			lg.Printf("gateway %s -> fabric %s", gw.Addr(), be.Addr())
		} else {
			lg.Printf("gateway %s -> fabric server managed externally (embedded/plugin mode)", gw.Addr())
		}
	} else if cfg.Backend.Enabled {
		lg.Printf("no gateway: bridging directly to fabric %s (it must speak the Eaglercraft protocol)", be.Addr())
	}

	if err := srv.Serve(ln); err != nil && !errors.Is(err, http.ErrServerClosed) {
		lg.Fatalf("serve: %v", err)
	}
	lg.Printf("stopped")
}
