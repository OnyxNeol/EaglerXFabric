// Package mods implements the mod ingestion engine: a secure endpoint to
// upload .jar mods directly into the Fabric backend's mods/ folder, with ZIP
// signature verification, plus delete/list operations.
//
// Carried over from the system extracted from EaglerCMP
// (eaglercmp/manager/mods.go); authentication moved to the API layer and the
// endpoint paths live under the API prefix.
package mods

import (
	"errors"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"

	"eaglerd/supervisor"
)

// errNotJar is returned when an upload lacks the PK zip signature.
var errNotJar = errors.New("file is not a valid .jar (missing zip signature or empty)")

// modNameRe constrains uploaded file names to a safe, predictable set.
var modNameRe = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9._+() -]{0,120}\.jar$`)

// MaxModSize is the default upload cap (256 MB).
const MaxModSize = 256 << 20

// Mods lists, stores and removes .jar mods in the backend's mods directory.
type Mods struct {
	Backend *supervisor.Backend
	// MaxBytes caps the size of one upload.
	MaxBytes int64
}

// Info describes one installed mod.
type Info struct {
	Name string `json:"name"`
	Size int64  `json:"size"`
}

// List returns the .jar files currently in the backend mods directory.
func (m *Mods) List() []Info {
	out := []Info{}
	entries, _ := os.ReadDir(m.Backend.ModsDir())
	for _, e := range entries {
		if info, err := e.Info(); err == nil && info.Mode().IsRegular() && filepath.Ext(e.Name()) == ".jar" {
			out = append(out, Info{e.Name(), info.Size()})
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Name < out[j].Name })
	return out
}

// ValidName reports whether a mod file name is acceptable.
func ValidName(name string) bool { return modNameRe.MatchString(name) }

// Save streams an uploaded jar to a temp file, checks the ZIP signature,
// then renames it into place so the server never sees a partial jar.
func (m *Mods) Save(name string, body io.Reader) error {
	max := m.MaxBytes
	if max <= 0 {
		max = MaxModSize
	}
	if !modNameRe.MatchString(name) {
		return errors.New("invalid file name: use letters, digits and . _ + - ( ) and end with .jar")
	}
	dir := m.Backend.ModsDir()
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return err
	}
	tmp, err := os.CreateTemp(dir, ".upload-*")
	if err != nil {
		return err
	}
	defer os.Remove(tmp.Name())
	n, err := io.Copy(tmp, io.LimitReader(body, max+1))
	if cerr := tmp.Close(); err == nil {
		err = cerr
	}
	if err != nil {
		return err
	}
	if n > max {
		return errors.New("mod exceeds the maximum upload size")
	}
	head := make([]byte, 4)
	f, err := os.Open(tmp.Name())
	if err != nil {
		return err
	}
	_, rerr := io.ReadFull(f, head)
	f.Close()
	if n == 0 || rerr != nil || string(head) != "PK\x03\x04" {
		return errNotJar
	}
	return os.Rename(tmp.Name(), filepath.Join(dir, name))
}

// Remove deletes a mod by file name.
func (m *Mods) Remove(name string) error {
	if !modNameRe.MatchString(name) {
		return errors.New("invalid file name")
	}
	err := os.Remove(filepath.Join(m.Backend.ModsDir(), name))
	if os.IsNotExist(err) {
		return nil
	}
	return err
}
