// jarpacker assembles eaglerd plugin jars using Go: it packages the
// javac-compiled classes, fabric.mod.json mod metadata, the jar manifest and
// (for the sidecar variant) the compiled eaglerd daemon binary into a valid,
// PK-signed .jar that Fabric drops into mods/.
//
// Two build flavors:
//
//   - the independent plugin (plugin-pure): no binary payload, the whole
//     system is the packaged Java classes; -bin may be omitted.
//   - the sidecar loader (plugin): -bin embeds dist/eaglerd-linux-amd64.
//
// Examples:
//
//	go run ./tools/jarpacker \
//	  -classes plugin-pure/build/classes \
//	  -out dist/eaglerd-plugin-1.0.0.jar -version 1.0.0 \
//	  -modid eaglerd-plugin -name "eaglerd plugin" \
//	  -entry dev.eaglerd.plugin.EaglerdPlugin
//
//	go run ./tools/jarpacker \
//	  -classes plugin/build/classes \
//	  -bin dist/eaglerd-linux-amd64 \
//	  -out dist/eaglerd-fabric-loader-1.0.0.jar -version 1.0.0 \
//	  -modid eaglerd -name "eaglerd fabric loader" \
//	  -entry dev.eaglerd.LoaderMod
package main

import (
	"archive/zip"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"
)

func main() {
	classes := flag.String("classes", "", "directory of compiled .class files (javac output)")
	bin := flag.String("bin", "", "optional native binary to embed at eaglerd-bin/")
	out := flag.String("out", "dist/plugin.jar", "output jar path")
	version := flag.String("version", "1.0.0", "mod version")
	modid := flag.String("modid", "eaglerd", "fabric.mod.json id")
	name := flag.String("name", "eaglerd", "mod display name")
	desc := flag.String("desc", "Eaglercraft WebSocket bridge and gateway JVM supervisor, running fully inside the server.", "mod description")
	entry := flag.String("entry", "dev.eaglerd.plugin.EaglerdPlugin",
		"fabric main entrypoint class(es); comma-separated for multiple, order preserved")
	flag.Parse()

	// build the JSON array for entrypoints.main, preserving order
	var entryArr strings.Builder
	entryArr.WriteString("[ ")
	for i, e := range strings.Split(*entry, ",") {
		if i > 0 {
			entryArr.WriteString(", ")
		}
		entryArr.WriteString("\"" + strings.TrimSpace(e) + "\"")
	}
	entryArr.WriteString(" ]")

	jar, err := os.Create(*out)
	must(err)
	defer jar.Close()
	zw := zip.NewWriter(jar)

	addBytes(zw, "META-INF/MANIFEST.MF", []byte(fmt.Sprintf(manifestT, *name, *version, *entry)))

	fabricMod := fmt.Sprintf(fabricModT, *modid, *version, *name, *desc, entryArr.String())
	addBytes(zw, "fabric.mod.json", []byte(fabricMod))

	err = filepath.WalkDir(*classes, func(path string, d os.DirEntry, err error) error {
		if err != nil || d.IsDir() {
			return err
		}
		if !strings.HasSuffix(path, ".class") {
			return nil
		}
		rel, err := filepath.Rel(*classes, path)
		if err != nil {
			return err
		}
		data, err := os.ReadFile(path)
		if err != nil {
			return err
		}
		return addBytes(zw, filepath.ToSlash(rel), data)
	})
	must(err)

	if *bin != "" {
		binData, err := os.ReadFile(*bin)
		must(err)
		must(addStored(zw, "eaglerd-bin/eaglerd-linux-amd64", binData))
		fmt.Printf("embedded binary: %d bytes\n", len(binData))
	}

	must(zw.Close())
	st, _ := jar.Stat()
	fmt.Printf("jar written: %s (%d bytes)\n", *out, st.Size())
}

const manifestT = `Manifest-Version: 1.0
Implementation-Title: %s
Implementation-Version: %s
Built-By: jarpacker (Go)
Main-Class: %s
`

const fabricModT = `{
  "schemaVersion": 1,
  "id": "%s",
  "version": "%s",
  "name": "%s",
  "description": "%s",
  "authors": ["eaglerd"],
  "contact": {},
  "license": "MIT",
  "environment": "server",
  "entrypoints": {
    "main": %s
  },
  "depends": {
    "fabricloader": ">=0.16.0"
  }
}
`

func addBytes(zw *zip.Writer, name string, data []byte) error {
	w, err := zw.CreateHeader(&zip.FileHeader{Name: name, Method: zip.Deflate, Modified: time.Now()})
	if err != nil {
		return err
	}
	_, err = w.Write(data)
	return err
}

// addStored writes an entry without compression (native binaries gain nothing).
func addStored(zw *zip.Writer, name string, data []byte) error {
	w, err := zw.CreateHeader(&zip.FileHeader{Name: name, Method: zip.Store, Modified: time.Now()})
	if err != nil {
		return err
	}
	_, err = w.Write(data)
	return err
}

func must(err error) {
	if err != nil {
		fmt.Fprintln(os.Stderr, "jarpacker:", err)
		os.Exit(1)
	}
}
