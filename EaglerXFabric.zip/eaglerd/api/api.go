// Package api exposes the management REST API under the configured prefix:
//
//	GET    /status   backend + gateway state, CPU/RAM, restarts, uptime
//	GET    /logs     tail of a backend console log (?backend=gateway&lines=200)
//	GET    /mods     installed .jar mods + backend state
//	POST   /mods     upload a mod: body = raw .jar, ?name=file.jar
//	DELETE /mods     remove a mod: ?name=file.jar
//	POST   /restart  graceful stop + start of the backend (applies mod changes)
//	POST   /stop     graceful stop, leaves the server stopped
//	POST   /start    start the server
//
// When cfg.AuthToken is set, every call must carry it in X-Api-Token or
// Authorization: Bearer, so the endpoint is safe to expose on a panel.
package api

import (
	"encoding/json"
	"net/http"
	"os"
	"strconv"
	"strings"

	"eaglerd/config"
	"eaglerd/mods"
	"eaglerd/supervisor"
)

// API bundles the HTTP handlers for the management surface.
type API struct {
	Backend *supervisor.Backend
	Gateway *supervisor.Backend // nil when disabled
	Mods    *mods.Mods
	Cfg     *config.Config
}

func (a *API) authed(r *http.Request) bool {
	if a.Cfg.AuthToken == "" {
		return true
	}
	tok := r.Header.Get("X-Api-Token")
	if tok == "" {
		if h := r.Header.Get("Authorization"); strings.HasPrefix(h, "Bearer ") {
			tok = strings.TrimPrefix(h, "Bearer ")
		}
	}
	return tok == a.Cfg.AuthToken
}

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(v)
}

// ServeHTTP routes /api/<endpoint> after checking the auth token.
func (a *API) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if !a.authed(r) {
		writeJSON(w, http.StatusUnauthorized, map[string]string{"error": "missing or invalid API token"})
		return
	}
	endpoint := strings.TrimPrefix(r.URL.Path, a.Cfg.APIPrefix)
	endpoint = strings.Trim(endpoint, "/")
	switch {
	case endpoint == "status" && r.Method == http.MethodGet:
		a.status(w)

	case endpoint == "logs" && r.Method == http.MethodGet:
		a.logs(w, r)

	case endpoint == "mods":
		a.modEndpoint(w, r)

	case endpoint == "restart" && r.Method == http.MethodPost:
		a.Backend.Restart()
		writeJSON(w, http.StatusOK, map[string]string{"status": "restarting"})

	case endpoint == "stop" && r.Method == http.MethodPost:
		if !a.Backend.Cfg.Enabled {
			writeJSON(w, http.StatusConflict, map[string]string{"error": "backend is disabled in config"})
			return
		}
		a.Backend.Stop()
		writeJSON(w, http.StatusOK, map[string]string{"status": "stopping"})

	case endpoint == "start" && r.Method == http.MethodPost:
		if !a.Backend.Cfg.Enabled {
			writeJSON(w, http.StatusConflict, map[string]string{"error": "backend is disabled in config"})
			return
		}
		a.Backend.Start()
		writeJSON(w, http.StatusOK, map[string]string{"status": "starting"})

	default:
		writeJSON(w, http.StatusNotFound, map[string]string{"error": "unknown endpoint " + r.URL.Path})
	}
}

func (a *API) status(w http.ResponseWriter) {
	out := map[string]any{"backend": a.Backend.Snapshot()}
	if a.Gateway != nil {
		out["gateway"] = a.Gateway.Snapshot()
	}
	writeJSON(w, http.StatusOK, out)
}

func (a *API) logs(w http.ResponseWriter, r *http.Request) {
	b := a.Backend
	if r.URL.Query().Get("backend") == "gateway" {
		if a.Gateway == nil {
			writeJSON(w, http.StatusNotFound, map[string]string{"error": "gateway is disabled"})
			return
		}
		b = a.Gateway
	}
	lines := 200
	if v, err := strconv.Atoi(r.URL.Query().Get("lines")); err == nil && v > 0 && v <= 10000 {
		lines = v
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"file":  b.LogPath(),
		"lines": strings.Split(supervisor.Tail(b.LogPath(), lines*160), "\n"),
	})
}

func (a *API) modEndpoint(w http.ResponseWriter, r *http.Request) {
	name := r.URL.Query().Get("name")
	switch r.Method {
	case http.MethodGet:
		state, msg := a.Backend.Status()
		writeJSON(w, http.StatusOK, map[string]any{
			"mods":    a.Mods.List(),
			"backend": map[string]any{"state": state, "error": msg},
		})
	case http.MethodPost:
		max := int64(a.Cfg.MaxModMB) << 20
		if max <= 0 {
			max = mods.MaxModSize
		}
		r.Body = http.MaxBytesReader(w, r.Body, max+1)
		if err := a.Mods.Save(name, r.Body); err != nil {
			code := http.StatusBadRequest
			if os.IsPermission(err) {
				code = http.StatusInternalServerError
			}
			writeJSON(w, code, map[string]string{"error": err.Error()})
			return
		}
		writeJSON(w, http.StatusOK, map[string]any{"mods": a.Mods.List()})
	case http.MethodDelete:
		if err := a.Mods.Remove(name); err != nil {
			writeJSON(w, http.StatusBadRequest, map[string]string{"error": err.Error()})
			return
		}
		writeJSON(w, http.StatusOK, map[string]any{"mods": a.Mods.List()})
	default:
		writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "method not allowed"})
	}
}
