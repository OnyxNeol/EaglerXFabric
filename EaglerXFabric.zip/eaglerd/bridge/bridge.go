// Package bridge tunnels Eaglercraft browser WebSocket connections to the
// local JVM backend's Eaglercraft WebSocket listener, byte by byte.
//
// Derived from the system extracted from EaglerCMP
// (eaglercmp/manager/bridge.go), which used a raw HTTP-hijack tunnel; here it
// is a real WebSocket endpoint (the web server is public, so the upgrade
// happens in the daemon and the frames are relayed verbatim to the gateway:
// Velocity + EaglerXServer performs the Eaglercraft protocol handshake and
// speaks the protocol itself, so no frames are parsed or translated here).
package bridge

import (
	"encoding/json"
	"net"
	"net/http"
	"strings"
	"time"

	"github.com/gorilla/websocket"

	"eaglerd/supervisor"
)

// Bridge tunnels WebSocket connections to Target's Eaglercraft listener.
type Bridge struct {
	Target *supervisor.Backend
	// AllowedOrigins: when non-empty, only these Origins may connect.
	// Empty means allow all (the Java-side gateway can still reject).
	AllowedOrigins []string
	DialTimeout    time.Duration
}

var upgrader = websocket.Upgrader{
	ReadBufferSize:  16384,
	WriteBufferSize: 16384,
	CheckOrigin:     func(*http.Request) bool { return true }, // per-bridge check below
}

func (b *Bridge) originAllowed(r *http.Request) bool {
	if len(b.AllowedOrigins) == 0 {
		return true
	}
	o := r.Header.Get("Origin")
	for _, a := range b.AllowedOrigins {
		if o == a || a == "*" {
			return true
		}
	}
	return false
}

func writeJSONError(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(v)
}

// ServeHTTP upgrades the connection (if the backend is ready) and pipes
// bytes between the browser and the gateway's Eaglercraft listener until
// either side disconnects.
func (b *Bridge) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if !strings.EqualFold(r.Header.Get("Upgrade"), "websocket") {
		writeJSONError(w, http.StatusBadRequest, map[string]string{"error": "websocket upgrade required"})
		return
	}
	if !b.originAllowed(r) {
		writeJSONError(w, http.StatusForbidden, map[string]string{"error": "origin not allowed"})
		return
	}
	state, msg := b.Target.Status()
	if state != string(supervisor.StateReady) {
		writeJSONError(w, http.StatusServiceUnavailable, map[string]string{
			"error": "backend is not ready (state: " + state + ")", "detail": msg, "state": state,
		})
		return
	}
	timeout := b.DialTimeout
	if timeout == 0 {
		timeout = 5 * time.Second
	}
	back, err := net.DialTimeout("tcp", b.Target.Addr(), timeout)
	if err != nil {
		writeJSONError(w, http.StatusBadGateway, map[string]string{"error": "backend dial failed: " + err.Error()})
		return
	}
	defer back.Close()

	ws, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		return // Upgrade already wrote the HTTP error
	}
	defer ws.Close()
	ws.SetReadLimit(32 << 20) // generous: chunked Minecraft payloads

	errCh := make(chan error, 2)
	go func() { errCh <- b.wsToTCP(ws, back) }()
	go func() { errCh <- b.tcpToWS(ws, back) }()
	<-errCh
}

func (b *Bridge) wsToTCP(ws *websocket.Conn, tcp net.Conn) error {
	for {
		_, data, err := ws.ReadMessage()
		if err != nil {
			return err
		}
		if _, err := tcp.Write(data); err != nil {
			return err
		}
	}
}

func (b *Bridge) tcpToWS(ws *websocket.Conn, tcp net.Conn) error {
	buf := make([]byte, 32768)
	for {
		n, err := tcp.Read(buf)
		if n > 0 {
			if werr := ws.WriteMessage(websocket.BinaryMessage, buf[:n]); werr != nil {
				return werr
			}
		}
		if err != nil {
			return err
		}
	}
}
