# eaglerd

A modern, deployable Eaglercraft server gateway with **integrated Fabric JVM
process management**, designed for Linux VPS, cloud nodes and hosting panels
(Docker, Pterodactyl, systemd).

The architecture is built on the system extracted from EaglerCMP (its
`manager/jvm.go` supervisor, `manager/bridge.go` WebSocket tunnel,
`manager/mods.go` mod ingestion and `scripts/setup-local-stack.sh`
provisioning), reworked from a desktop launcher into a headless server daemon:

```
Eaglercraft browser client (any origin, wss://host:25565/)
        │  WebSocket (byte-level tunnel, no frames parsed)
        ▼
   eaglerd  ──────────────────────────────────────────────┐
   │  supervises, monitors and manages both JVMs:         │ REST API /api/*
   ▼                                                      │ (mods, restart,
  gateway/  Velocity + EaglerXServer                      │  stop, status,
        │  Eaglercraft protocol → Minecraft packets       │  CPU/RAM)
        ▼  ViaVersion / ViaBackwards = multi-version      │
  backend/  Fabric server (mods in backend/mods/*.jar) ────┘
```

## Features

- **JVM supervisor** (`supervisor/`): spawns `java -jar fabric-server-launch.jar
  nogui` in the server directory, probes the loopback port before routing
  clients, restarts with exponential backoff (1s → 30s), and gives up into an
  error state after 3 fast crashes (no infinite crash loops).
- **Resource tracking**: live CPU % and RSS of each JVM read from `/proc`.
- **Mod ingestion** (`mods/`): upload `.jar` mods over REST; ZIP signature
  (`PK\x03\x04`) is verified and the file is renamed into `mods/` atomically,
  so the server never sees a partial jar.
- **Graceful lifecycle**: restart/stop write `stop` to the server console and
  wait (default 20s) before SIGINT/SIGKILL, so worlds never corrupt.
- **WebSocket bridge** (`bridge/`): byte-level tunnel to the gateway's
  Eaglercraft listener; returns 503 with state info while the backend is not
  ready, blocks cross-site requests when an origin allowlist is configured.
- **Multi-version**: ViaVersion / ViaBackwards plugins installed by
  `setup.sh`, so browser clients on supported protocol ranges can connect.
- **Panel-friendly**: JSON config + `EAGLERD_*` env overrides, one public port,
  `/healthz`, token-protected API, ships with Dockerfile, docker-compose,
  systemd unit and a Pterodactyl egg template.

## Quick start (bare Linux)

```bash
# needs: JDK 21+, curl, jq
./setup.sh                 # provisions backend/ (Fabric + Fabric API) and
                           # gateway/ (Velocity + EaglerXServer + ViaVersion)
./eaglerd -config eaglerd.json
```

Clients connect to `wss://your-host:25565/`. Setup honors `MC_VERSION`,
`VELOCITY_BUILD`, `EAGLERXSERVER_URL`, `FABRIC_API_URL` (pin direct jar URLs if
a Modrinth slug misses; slugs used: `eaglerxserver`, `viaversion`,
`viabackwards`, `fabric-api`).

## Configuration (`eaglerd.json`)

```json
{
  "listenPort": 25565,        // public WebSocket + API port
  "bridgePath": "/",          // WebSocket endpoint
  "apiPrefix": "/api",
  "authToken": "secret",      // required on /api (X-Api-Token or Bearer)
  "maxModMB": 256,
  "allowedOrigins": [],       // empty = allow all (gateway can also check)
  "logDir": "logs",
  "backend": {                // Fabric JVM (loopback :25566)
    "enabled": true, "java": "java", "dir": "backend",
    "jar": "fabric-server-launch.jar", "jvmArgs": ["-Xmx2G"],
    "args": ["nogui"], "port": 25566, "gracefulStopSec": 20
  },
  "gateway": {                // Velocity + EaglerXServer JVM (loopback :25577)
    "enabled": true, "dir": "gateway", "jar": "velocity.jar",
    "jvmArgs": ["-Xmx512M"], "args": [], "port": 25577
  }
}
```

Environment overrides: `EAGLERD_LISTEN_PORT`, `EAGLERD_BRIDGE_PATH`,
`EAGLERD_AUTH_TOKEN`, `EAGLERD_XMX` (e.g. `4G`), `EAGLERD_JVM_ARGS`,
`EAGLERD_BACKEND_ENABLED`, `EAGLERD_BACKEND_DIR`, `EAGLERD_JAR`,
`EAGLERD_BACKEND_PORT`, `EAGLERD_GATEWAY_ENABLED`, `EAGLERD_GATEWAY_PORT`,
`EAGLERD_MAX_MOD_MB`, `EAGLERD_LOG_DIR`, `EAGLERD_ALLOWED_ORIGINS`.

Disabling the gateway bridges clients directly to the Fabric port; in that
case the backend itself must speak the Eaglercraft protocol (e.g. an
Eaglercraft-aware server mod).

## REST API

All endpoints live under `apiPrefix` and require the token when
`authToken` is set.

| Method   | Endpoint  | Purpose |
|----------|-----------|---------|
| GET      | `/api/status` | state, PID, uptime, restarts, CPU %, RSS for backend + gateway |
| GET      | `/api/mods` | list installed `.jar` mods |
| POST     | `/api/mods?name=x.jar` | upload a mod (body = raw jar bytes) |
| DELETE   | `/api/mods?name=x.jar` | remove a mod |
| POST     | `/api/restart` | graceful stop + start (loads new mods) |
| POST     | `/api/stop` | graceful stop, stays stopped |
| POST     | `/api/start` | start the server |
| GET      | `/api/logs?lines=200&backend=gateway` | tail a console log |
| GET      | `/healthz` | unauthenticated liveness probe |

Examples:

```bash
TOKEN="X-Api-Token: s3cret"

curl -sH "$TOKEN" https://host:25565/api/status
curl -sH "$TOKEN" -X POST --data-binary @mymod.jar \
  "https://host:25565/api/mods?name=mymod.jar"
curl -sH "$TOKEN" -X POST https://host:25565/api/restart
```

## Deployment

**Docker / Compose**

```bash
docker compose run --rm eaglerd setup-eaglerd.sh   # provision once
docker compose up -d
```

**systemd** — copy the tree to `/opt/eaglerd`, then
`systemctl enable --now eaglerd` (unit in `systemd/eaglerd.service`).

**Pterodactyl** — import `pterodactyl/egg-eaglerd.json` (template: point the
docker image at a build of the provided Dockerfile and set the binary URL
variable; the egg's install script downloads `eaglerd` + runs `setup.sh`).
The panel stop signal (SIGINT) triggers a graceful JVM shutdown, and
`EAGLERD_*` variables map panel fields onto the daemon config.

## Building

```bash
go build -o eaglerd .        # or: make build
CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -o eaglerd-linux-amd64 .
```

## Notes

- eaglerd never parses Eaglercraft protocol frames: the gateway (Velocity +
  EaglerXServer) owns the protocol, which keeps the daemon simple and lets
  multi-version support come from ViaVersion/ViaBackwards.
- Console logs land in `<logDir>/backend.log` and `<logDir>/gateway.log`.
- The JVM supervisor is a server-grade port of EaglerCMP's proven
  `Backend.Run` loop, extended with `/proc` resource sampling and console
  ("stop")-based graceful shutdown.

## Quickstart (the independent plugin)

The whole Eaglercraft -> Fabric stack in **two steps**:

1. Drop `eaglerd-plugin-1.2.0.jar` into your Fabric server's `mods/` folder.
2. Start the server. That's it.

On first boot the plugin does everything a human would have to: generates
`eaglerd-plugin.json` with a random management token, fixes
`server.properties` (backup kept in `server.properties.eaglerd.bak`:
moves the server off port 25565, sets `online-mode=false`,
`server-ip=127.0.0.1`), downloads Velocity (the newest build your JVM can
run, via PaperMC's Fill v3 API), EaglerXServer, ViaVersion and ViaBackwards
from Modrinth into `gateway/`, and writes a ready `velocity.toml`. The
startup banner then prints exactly where Eaglercraft players connect and
your management token. Offline server? Pin direct jar URLs under `setup`
in the config (or `EAGLERD_VELOCITY_URL`, `EAGLERD_EAGLERX_URL`, ...).

Pointing a browser at the server port shows a sleek glassmorphism
status page (Tailwind design, aurora backdrop) with the exact connect
address and a copy button; `/api/status` tells owners the same in JSON.

Every connection is served by Java 21 virtual threads: 500 players
joining in the same second stay smooth (verified: a 500-client
simultaneous burst completed with p95 latency under 1.3s on a single
CPU core, and the management API stayed responsive throughout).

## Supported Eaglercraft clients

The full eaglercraft.com client lineup works out of the box (verified
against a real Fabric 1.21.1 backend, see `plugin-pure/test_versions.py`):

| Client              | Protocol        | Via                                   |
|---------------------|-----------------|---------------------------------------|
| Eaglercraft 26.2 "zeus" | MC 776, handshake v5 | EaglerXServer v5 + ViaVersion (client newer than backend) |
| Eaglercraft 1.12.2  | MC 340, handshake v4 | ViaBackwards |
| EaglercraftX 1.8.8  | MC 47, handshake v4  | ViaBackwards + ViaRewind |
| Eaglercraft 1.5.2   | legacy rewind 69 | EaglerXRewind (auto-provisioned) |

All of these join through one plugin jar; first boot provisions
everything they need. Future Eaglercraft clients (e.g. 26.3 when it
ships) need only an updated ViaVersion jar on the gateway - no
structural change.

## Independent server plugin (`.jar`) — no daemon, no binary payload

`dist/eaglerd-plugin-1.2.0.jar` (30 KB) is the entire eaglerd system as one
pure-Java Fabric server-side mod. Drop it into `mods/` — nothing else runs
on the box except the Velocity gateway it supervises:

- **Eaglercraft pass-through**: when a client sends an HTTP `Upgrade:
  websocket` handshake, the plugin relays the raw byte stream (handshake
  untouched) to the gateway's Eaglercraft listener on `127.0.0.1:25577` and
  pumps both directions. EaglerXServer terminates the WebSocket itself and
  speaks the Eaglercraft protocol inside it — the plugin never interprets a
  frame, so any protocol version works unchanged. The REST API and status
  page share the same public port.
- **Gateway JVM supervisor**: pure-Java port of the extracted `manager/jvm.go`
  loop — preflight, readiness probe, exponential backoff, 3-fast-fail error
  state, /proc CPU/RAM sampling, graceful console-`stop` shutdown. The
  shutdown hook joins the supervisor so a server stop never orphans the JVM.
- **Management REST API**: `/api/status|mods|restart|stop|start|logs` on the
  same port; uploads land in this server's own `mods/` with ZIP signature
  verification and atomic rename; token auth via `X-Api-Token`.
- **Zero dependencies**: no Go, no native binary, no shaded libs — only
  fabric-loader and slf4j (both provided by Fabric at runtime). `Json.java`,
  `Config.java`, `GatewaySupervisor.java`, `Setup.java`,
  `ServerProperties.java`, `ModsStore.java`, `EaglerdHttpServer.java`,
  `EaglerdPlugin.java`.

Setup: see the Quickstart above — the plugin self-provisions on first
boot (server.properties fix, gateway downloads, velocity.toml, config with
generated token). Everything can be pinned or disabled in `eaglerd-plugin.json`
(`setup.autoSetup`, `setup.autoFixServerProperties`, direct URLs) or via env
(`EAGLERD_LISTEN_PORT`, `EAGLERD_AUTH_TOKEN`, `EAGLERD_GATEWAY_*`,
`EAGLERD_XMX`, `EAGLERD_VELOCITY_URL`, `EAGLERD_EAGLERX_URL`).

Build and test:

```bash
make plugin-pure                 # javac + jarpacker (Go assembles the jar)
python3 plugin-pure/test_plugin.py   # full end-to-end regression (fake JVM)
# standalone smoke test:
java -cp dist/eaglerd-plugin-1.2.0.jar:fabric-loader.jar:slf4j-api.jar \
  dev.eaglerd.plugin.EaglerdPlugin
```

## Fabric server-side plugin (`.jar`) — embedded mode

`dist/eaglerd-fabric-loader-<version>.jar` is a real Fabric server-side mod
that carries the whole eaglerd system as an embedded native payload:

- `plugin/src/dev/eaglerd/LoaderMod.java` — a tiny `ModInitializer` that
  extracts the embedded linux-amd64 daemon binary (atomic write, re-extracts
  only when it changes), launches it with
  `EAGLERD_BACKEND_ENABLED=false` and `EAGLERD_GATEWAY_ENABLED=true`, wires
  its log into `logs/`, and stops it cleanly on server shutdown.
- `tools/jarpacker` — the **Go** program that assembles the `.jar`: javac
  output classes, `fabric.mod.json`, `META-INF/MANIFEST.MF` and the compiled
  daemon binary at `eaglerd-bin/eaglerd-linux-amd64`.

Why the loader is Java: a plugin jar must contain JVM bytecode, and Go cannot
emit that; what Go *does* own here is the entire embedded system plus the jar
assembly itself.

In embedded mode **the Fabric server that loaded the mod is the backend**: set
`server-ip=127.0.0.1`, `server-port=25566`, `online-mode=false` in
`server.properties`, provision `gateway/` with `setup.sh`, and drop the jar
into `mods/`. The mod touches no Minecraft classes, so it loads on any
Minecraft/Fabric version the loader supports.

Build it:

```bash
make plugin        # javac + go build + jarpacker (needs JDK 21+)
# or manually:
javac --release 21 -cp vendor-jars/fabric-loader.jar:vendor-jars/slf4j-api.jar \\
  -d plugin/build/classes plugin/src/dev/eaglerd/LoaderMod.java
go run ./tools/jarpacker -classes plugin/build/classes \\
  -bin dist/eaglerd-linux-amd64 -out dist/eaglerd-fabric-loader-1.0.0.jar -version 1.0.0
```

Verify it end-to-end without a real server (uses a fake JVM):

```bash
python3 plugin/test_embed.py   # plugin -> daemon -> gateway -> bridge echo + graceful stop
```

Standalone smoke test (no Fabric needed):

```bash
java -cp eaglerd-fabric-loader.jar:fabric-loader.jar:slf4j-api.jar dev.eaglerd.LoaderMod
```
