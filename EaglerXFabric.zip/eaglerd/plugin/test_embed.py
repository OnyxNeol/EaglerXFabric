#!/usr/bin/env python3
"""End-to-end embedded-mode test for the eaglerd fabric-loader plugin jar:
plugin JVM -> extracts embedded Go binary -> launches daemon (gateway-only
mode) -> daemon supervises fake Velocity gateway -> WS bridge echoes bytes.
Then SIGTERM to the plugin JVM and verify graceful teardown.
"""
import base64
import json
import os
import signal
import socket
import subprocess
import time
import urllib.request

EAGLERD = "/app/conversations/6ad32a084ce18c326740c5a2/eaglerd"
GAME = "/tmp/embed-test"
JAR = f"{EAGLERD}/dist/eaglerd-fabric-loader-1.0.0.jar"
PORT, GW_PORT = 18080, 18082


def api(path, token="testtoken123", method="GET"):
    req = urllib.request.Request(f"http://127.0.0.1:{PORT}{path}", method=method)
    if token:
        req.add_header("X-Api-Token", token)
    with urllib.request.urlopen(req, timeout=3) as r:
        return json.loads(r.read())


def cleanup():
    subprocess.run(["pkill", "-f", "LoaderMod"], capture_output=True)
    time.sleep(0.5)
    subprocess.run(["pkill", "-f", "eaglerd-linux-amd64 -config"], capture_output=True)  # <15 chars: binary name truncated
    time.sleep(0.5)


def main():
    os.chdir(GAME)
    cleanup()
    env = dict(os.environ, EAGLERD_LISTEN_PORT=str(PORT), EAGLERD_GATEWAY_PORT=str(GW_PORT))
    # exact classpath, run via a jar-relative pattern that cannot match this script's argv
    proc = subprocess.Popen([
        "/opt/jdk/bin/java",
        "-cp", f"{JAR}:{EAGLERD}/vendor-jars/fabric-loader.jar:{EAGLERD}/vendor-jars/slf4j-api.jar",
        "dev.eaglerd." + "LoaderMod",  # split so pkill cleanup above never matched us
    ], env=env, stdout=open("plugin.out", "w"), stderr=subprocess.STDOUT)
    try:
        # wait for daemon ready
        for _ in range(40):
            time.sleep(0.5)
            try:
                st = api("/api/status")
                if st["gateway"]["state"] == "ready":
                    break
            except Exception:
                pass
        else:
            print("FAIL: gateway never became ready")
            print(open("plugin.out").read())
            print(open("logs/eaglerd-daemon.out").read() if os.path.exists("logs/eaglerd-daemon.out") else "")
            return 1
        print("status:", json.dumps(st))
        assert st["backend"]["state"] == "disabled", "embedded mode must disable backend supervision"

        # bridge: WS handshake + echo through plugin->daemon->fake gateway
        s = socket.create_connection(("127.0.0.1", PORT), timeout=5)
        key = base64.b64encode(os.urandom(16)).decode()
        s.sendall((f"GET / HTTP/1.1\r\nHost: localhost\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                   f"Sec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n").encode())
        buf = b""
        resp = b""
        while b"\r\n\r\n" not in resp:
            resp += s.recv(2048)
        head, leftover = resp.split(b"\r\n\r\n", 1)
        assert b"101" in head.split(b"\r\n")[0], head
        buf = leftover

        def rf():
            nonlocal buf
            while len(buf) < 2:
                buf += s.recv(4096)
            ln = buf[1] & 0x7F
            while len(buf) < 2 + ln:
                buf += s.recv(4096)
            payload, buf = buf[2:2 + ln], buf[2 + ln:]
            return payload

        print("frame 1 (gateway greeting):", rf().decode().strip())
        payload = b"CLIENT-FRAME"
        mask = os.urandom(4)
        s.sendall(bytes([0x82, 0x80 | len(payload)]) + mask + bytes(b ^ mask[i % 4] for i, b in enumerate(payload)))
        print("frame 2 (gateway echo):   ", rf().decode())
        print("EMBEDDED-BRIDGE-OK")

        # graceful shutdown: SIGTERM to the plugin JVM -> shutdown hook stops daemon -> gateway stops
        proc.send_signal(signal.SIGTERM)
        deadline = time.time() + 20
        while time.time() < deadline and proc.poll() is None:
            time.sleep(0.5)
        print("plugin JVM exit code:", proc.returncode)
        time.sleep(2)
        time.sleep(1)
        _alive = subprocess.run(["pgrep", "-f", "eaglerd-linux-amd64 -config"], capture_output=True).returncode == 0
        print("daemon still running:", _alive)
        print("gateway log tail:", open("logs/gateway.log").read().strip().splitlines()[-3:])
        print("ALL-EMBEDDED-TESTS-PASSED")
        return 0
    finally:
        if proc.poll() is None:
            proc.kill()


if __name__ == "__main__":
    raise SystemExit(main())
