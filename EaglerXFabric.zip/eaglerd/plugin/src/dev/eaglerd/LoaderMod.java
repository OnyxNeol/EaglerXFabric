package dev.eaglerd;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * eaglerd-fabric-loader: a Fabric server-side mod whose only job is to carry
 * the eaglerd Go daemon as an embedded native payload and launch it inside
 * the server process tree.
 *
 * In this embedded mode the Fabric server that loaded this mod IS the
 * "backend": it must bind 127.0.0.1:25566 (server.properties: server-ip=127.0.0.1,
 * server-port=25566, online-mode=false). The daemon is started with the
 * backend supervisor disabled and the Velocity + EaglerXServer gateway
 * supervisor enabled, so the full stack still applies:
 *
 *   Eaglercraft browser -> eaglerd bridge (:25565) -> Velocity gateway
 *   (:25577) -> this Fabric server (:25566) with mods in mods/
 *
 * The jar is assembled by tools/jarpacker (Go), which embeds the compiled
 * linux-amd64 daemon binary at eaglerd-bin/eaglerd-linux-amd64.
 */
public final class LoaderMod implements ModInitializer {
    private static final Logger LOG = LoggerFactory.getLogger("eaglerd");
    private static final String BIN_RESOURCE = "/eaglerd-bin/eaglerd-linux-amd64";

    private static Process daemon;

    @Override
    public void onInitialize() {
        try {
            bootstrap();
        } catch (Exception e) {
            LOG.error("eaglerd daemon failed to start", e);
        }
    }

    /** Standalone entry point: `java -jar eaglerd-fabric-loader.jar` runs the
     * same bootstrap outside a Fabric server (handy for smoke tests). */
    public static void main(String[] args) throws Exception {
        bootstrap();
        // Keep the JVM alive so the child daemon keeps running until Ctrl-C.
        Thread.sleep(Long.MAX_VALUE);
    }

    private static void bootstrap() throws Exception {
        String os = System.getProperty("os.name", "").toLowerCase();
        String arch = System.getProperty("os.arch", "");
        if (!os.contains("linux") || !"amd64".equals(arch)) {
            LOG.error("eaglerd embedded binary supports linux/amd64 only (running on {} {})", os, arch);
            return;
        }

        Path gameDir = new File(System.getProperty("user.dir")).toPath();
        Path bin = gameDir.resolve("eaglerd").resolve("eaglerd-linux-amd64");
        Path logDir = gameDir.resolve("logs");
        Files.createDirectories(bin.getParent());
        Files.createDirectories(logDir);
        extractBinary(bin);

        List<String> cmd = new ArrayList<>();
        cmd.add(bin.toString());
        cmd.add("-config");
        cmd.add(gameDir.resolve("eaglerd.json").toString());

        ProcessBuilder pb = new ProcessBuilder(cmd);
        pb.directory(gameDir.toFile());
        // Embedded mode: THIS Fabric server is the backend; only supervise the gateway.
        pb.environment().put("EAGLERD_BACKEND_ENABLED", "false");
        pb.environment().put("EAGLERD_GATEWAY_ENABLED", "true");
        // Public Eaglercraft WebSocket port and panel overrides flow in from
        // the server's own environment via inheritance.
        pb.redirectErrorStream(true);
        pb.redirectOutput(logDir.resolve("eaglerd-daemon.out").toFile());

        daemon = pb.start();
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            if (daemon != null && daemon.isAlive()) {
                LOG.info("stopping eaglerd daemon (pid {})", daemon.pid());
                daemon.destroy(); // SIGTERM/SIGINT -> graceful gateway shutdown
            }
        }, "eaglerd-shutdown"));
        LOG.info("eaglerd daemon started (pid {}), gateway bridge will listen on the configured port", daemon.pid());
    }

    /**
     * Extracts the embedded daemon binary, writing it atomically and only
     * when the on-disk copy differs from the embedded one.
     */
    private static void extractBinary(Path dest) throws IOException {
        long embeddedLen = resourceSize();
        if (Files.exists(dest)) {
            try {
                if (Files.size(dest) == embeddedLen) {
                    makeExecutable(dest);
                    return;
                }
            } catch (IOException ignored) {
                // fall through and re-extract
            }
        }
        Path tmp = dest.resolveSibling(dest.getFileName().toString() + ".tmp");
        try (InputStream in = LoaderMod.class.getResourceAsStream(BIN_RESOURCE);
             OutputStream out = new FileOutputStream(tmp.toFile())) {
            if (in == null) {
                throw new IOException("embedded binary missing from jar: " + BIN_RESOURCE);
            }
            in.transferTo(out);
        }
        makeExecutable(tmp);
        Files.move(tmp, dest, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        makeExecutable(dest);
        LOG.info("extracted eaglerd daemon to {}", dest);
    }

    private static long resourceSize() throws IOException {
        InputStream in = LoaderMod.class.getResourceAsStream(BIN_RESOURCE);
        if (in == null) {
            throw new IOException("embedded binary missing from jar: " + BIN_RESOURCE);
        }
        try (in) {
            long n = 0;
            byte[] buf = new byte[8192];
            int r;
            while ((r = in.read(buf)) > 0) n += r;
            return n;
        }
    }

    private static void makeExecutable(Path p) throws IOException {
        File f = p.toFile();
        if (!f.setExecutable(true, true)) {
            throw new IOException("cannot make executable: " + p);
        }
    }
}
